import { system, world, EquipmentSlot, EntityInitializationCause} from '@minecraft/server';
import TechGuide from './TECH/openMenu.js';
import { Machines } from './TECH/Machines.js';
import * as MC from './TECH/MachinesConstants.js';
import CustomLight from './TECH/CustomEvents/CustomLight.js';
import Sushi from './TECH/CustomEvents/Sushi.js';
import BaconEggs from './TECH/CustomEvents/BaconEggs.js';
import SteakVeggies from './TECH/CustomEvents/SteakVeggies.js';
import SpicyStew from './TECH/CustomEvents/SpicyStew.js';
import Smoothie from './TECH/CustomEvents/Smoothie.js';
import MixedGrill from './TECH/CustomEvents/MixedGrill.js';
import Pasta from './TECH/CustomEvents/Pasta.js';
import TechGauntlet from './TECH/CustomEvents/TechGauntlet.js';
import TechAxe from './TECH/CustomEvents/TechAxe.js';
import ItemDurability from './TECH/CustomEvents/ItemDurability.js';
import BoostingPad from './TECH/CustomEvents/BoostingPad.js';
import OutputModule from './TECH/CustomEvents/OutputModule.js';
import VacuumModule from './TECH/CustomEvents/VacuumModule.js';
import BoomTNT from './TECH/CustomEvents/BoomTNT.js';
import Woodcutter from './TECH/CustomEvents/Woodcutter.js';
import ManualOreExtractor from './TECH/CustomEvents/ManualOreExtractor.js';
import { index } from './TECH/Machines/index.js';


index.initializeAll();

// Run Machine specific functions
system.runTimeout(() => {
    Machines.run();
}, 1);

world.beforeEvents.worldInitialize.subscribe(({ blockComponentRegistry, itemComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent('lv_te:mining_helmet_block',CustomLight);
    blockComponentRegistry.registerCustomComponent('lv_te:boosting_pad',BoostingPad);
    blockComponentRegistry.registerCustomComponent('lv_te:output_module',OutputModule);
    blockComponentRegistry.registerCustomComponent('lv_te:vacuum_module',VacuumModule);
    blockComponentRegistry.registerCustomComponent('lv_te:boom_tnt',BoomTNT);
    blockComponentRegistry.registerCustomComponent('lv_te:woodcutter',Woodcutter);
    blockComponentRegistry.registerCustomComponent('lv_te:manual_ore_extractor', ManualOreExtractor);
    itemComponentRegistry.registerCustomComponent("lv_te:sushi", Sushi);
    itemComponentRegistry.registerCustomComponent("lv_te:bacon_eggs", BaconEggs);
    itemComponentRegistry.registerCustomComponent("lv_te:steak_veggies", SteakVeggies);
    itemComponentRegistry.registerCustomComponent("lv_te:spicy_stew", SpicyStew);
    itemComponentRegistry.registerCustomComponent("lv_te:smoothie", Smoothie);
    itemComponentRegistry.registerCustomComponent("lv_te:mixed_grill", MixedGrill);
    itemComponentRegistry.registerCustomComponent("lv_te:pasta", Pasta);
    itemComponentRegistry.registerCustomComponent("lv_te:tech_gauntlet", TechGauntlet);
    itemComponentRegistry.registerCustomComponent("lv_te:tech_axe", TechAxe);
    itemComponentRegistry.registerCustomComponent("lv_te:item_durability", ItemDurability);
});
// Give Players the Menu item on spawn
world.afterEvents.playerSpawn.subscribe((event) => {
    const { player, initialSpawn } = event;
    player.setDynamicProperty('jetpackFuel', 100);
    if (!initialSpawn) return;
    const giveBook = system.runInterval(() => {
        try {
            if (!player.hasTag('lv_te:guide_book') && player.isOnGround) {
                player.runCommandAsync(`loot spawn ~~~ loot "lv/te/menu"`)
                player.addTag('lv_te:guide_book');
                system.clearRun(giveBook);
            }
        } catch (e) { }
    }, 5)
});

world.afterEvents.entitySpawn.subscribe((event) => {
    const { cause, entity } = event;
    if (cause === "Spawned") {
        if (entity.typeId === "lv_te:fred") {
            // Generate a unique tag using a timestamp or random value
            const uniqueTag = `pair_${Date.now()}_${Math.floor(Math.random() * 1000)}`;


            // Spawn the charging station using dimension.spawnEntity
            const chargingStation = entity.dimension.spawnEntity("lv_te:charging_station", entity.location);

            // Set the rotation for the charging station
            chargingStation.setRotation(entity.getRotation());

            // Add the unique tag to the spawning entity (lv_te:fred)
            entity.addTag(uniqueTag);
            // Add the unique tag to the charging station
            chargingStation.addTag(uniqueTag);
        }
    }
});




// Check if menu item is being used
world.afterEvents.itemStartUse.subscribe((event) => {
    const { source, itemStack } = event;
    if (!source || !itemStack) return;
    if (itemStack.typeId === "lv_te:menu") {
        TechGuide.openMenu(source);
    }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const { source, block } = event;

    try {
        // Check if the placed block is a machine in the MC.machines constant
        if (MC.machines.includes(block.typeId)) {
            const dimension = block.dimension;
            const blockLocation = block.location;
            const blockID = block.typeId;

            // Get the cardinal direction of the placed block
            const blockFacingDirection = block.permutation.getState("minecraft:cardinal_direction");

            // Define rotation mappings for each direction
            const rotationMap = {
                north: 0, // Maps to 180 degrees
                south: 180, // Maps to 0 degrees
                east: 90,  // Maps to -90 degrees
                west: -90,  // Maps to 90 degrees
            };

            try {
                // Check if the placed block is a machine in the MC.machines constant
                if (MC.machines.includes(block.typeId)) {
                    const dimension = block.dimension;
                    const blockLocation = block.location;
                    const blockID = block.typeId;

                    // Get the cardinal direction of the placed block
                    const blockFacingDirection = block.permutation.getState("minecraft:cardinal_direction");

                    // Get the corresponding facing direction for the entity
                    const facingDirection = rotationMap[blockFacingDirection] || 0; // Default to 0 if no match

                    // Remove the block

                    if (blockID === "lv_te:automatic_harvester") {
                        dimension.setBlockType(blockLocation, "minecraft:air");
                        dimension.runCommandAsync(`summon ${blockID} ${blockLocation.x + 0.5} ${blockLocation.y + 1} ${blockLocation.z + 0.5} ${facingDirection}`);
                        dimension.runCommandAsync(`particle lv_te:automatic_harvester_spawn ${blockLocation.x + 0.5} ${blockLocation.y + 1} ${blockLocation.z + 0.5}`);
                        return;
                    }
                    if (blockID === "lv_te:automatic_drill" || blockID === "lv_te:advanced_automatic_drill") {
                        
                        // Spawn the entity with the same name as the block typeId
                        dimension.setBlockType(blockLocation, "minecraft:air");
                        dimension.runCommandAsync(`summon ${blockID} ${blockLocation.x + 0.5} ${blockLocation.y + 0.1} ${blockLocation.z + 0.5} ${facingDirection}`)
                    }
                    else {
                        // Spawn the entity with the same name as the block typeId
                        dimension.setBlockType(blockLocation, "minecraft:air");
                        dimension.runCommandAsync(`summon ${blockID} ${blockLocation.x + 0.5} ${blockLocation.y} ${blockLocation.z + 0.5} ${facingDirection}`)
                    }
                }
            } catch (error) {
                console.error("Error handling playerPlaceBlock event:", error);
            }

        }
    } catch (error) {
        console.error("Error handling playerPlaceBlock event:", error);
    }
});



