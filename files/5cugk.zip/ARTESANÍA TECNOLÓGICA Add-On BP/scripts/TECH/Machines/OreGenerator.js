import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import { MachineClass } from '../MachineClass.js';
import * as MC from '../MachinesConstants.js';

export class OreGenerator {

    static initialize() {
        system.runInterval(() => {
            OreGenerator.runOreGenerator();
        }, 20); // Run every 1.5 seconds
    }

    static runOreGenerator() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity =>
                entity.typeId === "lv_te:ore_generator" || entity.typeId === "lv_te:advanced_ore_generator"
            );

            // Process each machine
            for (const machine of entities) {
                const interval = machine.typeId === "lv_te:advanced_ore_generator" ? 20 : 60; // 1.5 seconds for advanced, 3 seconds for regular

                if (!machine.getProperty("lv_te:generator_timer")) {
                    machine.setProperty("lv_te:generator_timer", interval);
                } else {
                    const timer = machine.getProperty("lv_te:generator_timer") - 20;
                    if (timer <= 0) {
                        OreGenerator.generateOre(machine, dimension);
                        machine.setProperty("lv_te:generator_timer", interval);
                    } else {
                        machine.setProperty("lv_te:generator_timer", timer);
                    }
                }
            }
        }
    }

    static generateOre(machine, dimension) {
        try {
            const machineConfig = MC.machineConfigs[machine.typeId];
            if (!MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage, true)) {
                return;
            }

            let hasSpace = false;
            if (dimension.getBlock({ x: machine.location.x, y: machine.location.y + 1, z: machine.location.z }).typeId === "minecraft:air" || dimension.getBlock({ x: machine.location.x, y: machine.location.y + 1, z: machine.location.z }).typeId == null) {
                hasSpace = true;
            }

            if (hasSpace) {
                MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage);

                // Determine the appropriate ore weights based on machine type
                const oreWeights = machine.typeId === "lv_te:advanced_ore_generator"
                    ? MC.ADV_ORE_GEN_WEIGHTS
                    : MC.ORE_GEN_WEIGHTS;

                // Use weighted random selection to pick an ore
                const selectedOre = OreGenerator.getWeightedRandomOre(oreWeights);

                // Place the selected ore block
                dimension.setBlockType(
                    { x: machine.location.x, y: machine.location.y + 1, z: machine.location.z },
                    selectedOre
                );

                machine.runCommand('particle lv_te:ore_generator_generate ~~1.5~');
                machine.runCommand('playsound place.tuff @a ~~~');
            }
        } catch (error) {

        }

    }

    // Helper function for weighted randomization
    static getWeightedRandomOre(weights) {
        const totalWeight = weights.reduce((sum, item) => sum + item.weight, 0);
        const random = Math.random() * totalWeight;

        let cumulativeWeight = 0;
        for (const item of weights) {
            cumulativeWeight += item.weight;
            if (random < cumulativeWeight) {
                return item.name;
            }
        }
        return weights[weights.length - 1].name; // Fallback in case of rounding errors
    }
}
