import { system, world, EntityComponentTypes, EquipmentSlot } from '@minecraft/server';

export class EquippableEffects {
    static initialize() {
        system.runInterval(() => {
            EquippableEffects.runEquippableEffects();
        }, 5); // Run every 5 ticks
    }

    static applyEffectWithTag(player, tagName, effect, duration, amplifier) {
        if (!player.hasTag(tagName)) {
            player.runCommand(`tag @s add ${tagName}`);
        }
        player.runCommand(`effect @s ${effect} ${duration} ${amplifier} true`);
    }

    static removeEffectWithTag(player, tagName, effect) {
        if (player.hasTag(tagName)) {
            player.runCommand(`tag @s remove ${tagName}`);
            player.runCommand(`effect @s ${effect} 0`);
        }
    }

    static getSlotForType(typeId) {
        if (typeId.includes("_helmet")) return EquipmentSlot.Head;
        if (typeId.includes("_chestplate")) return EquipmentSlot.Chest;
        if (typeId.includes("_leggings")) return EquipmentSlot.Legs;
        if (typeId.includes("_boots")) return EquipmentSlot.Feet;
        return null; // Fallback for invalid type IDs
    }

    static runEquippableEffects() {
        // Lookup table for individual armor bonuses
        const armorEffects = {
            "lv_te:tech_helmet": { tag: "wearing_tech_helmet", effect: "water_breathing", slot: EquipmentSlot.Head },
            "lv_te:tech_chestplate": { tag: "wearing_tech_chestplate", effect: "strength", slot: EquipmentSlot.Chest },
            "lv_te:tech_leggings": { tag: "wearing_tech_leggings", effect: "resistance", slot: EquipmentSlot.Legs },
            "lv_te:tech_boots": { tag: "wearing_tech_boots", effect: "speed", slot: EquipmentSlot.Feet },
            "lv_te:tech_googles": { tag: "wearing_night_vision_googles", effect: "night_vision", slot: EquipmentSlot.Head },
            "lv_te:titanium_helmet": { slot: EquipmentSlot.Head },
            "lv_te:titanium_chestplate": { slot: EquipmentSlot.Chest },
            "lv_te:titanium_leggings": { slot: EquipmentSlot.Legs },
            "lv_te:titanium_boots": { slot: EquipmentSlot.Feet },
            "lv_te:steel_helmet": { slot: EquipmentSlot.Head },
            "lv_te:steel_chestplate": { slot: EquipmentSlot.Chest },
            "lv_te:steel_leggings": { slot: EquipmentSlot.Legs },
            "lv_te:steel_boots": { slot: EquipmentSlot.Feet }
        };

        // Iterate through all players in the world
        for (const player of world.getPlayers()) {
            if (!player || !player.getComponent(EntityComponentTypes.Equippable)) continue;

            // Get the equippable component
            const equipComponent = player.getComponent(EntityComponentTypes.Equippable);

            // Handle individual armor and googles effects dynamically
            for (const [armorId, { tag, effect, slot }] of Object.entries(armorEffects)) {
                const item = equipComponent.getEquipment(slot);
                if (item && item.typeId === armorId && effect) {
                    EquippableEffects.applyEffectWithTag(player, tag, effect, 11, 0);
                } else if (effect) {
                    EquippableEffects.removeEffectWithTag(player, tag, effect);
                }
            }

            // Full set bonuses
            const titaniumSet = ["lv_te:titanium_helmet", "lv_te:titanium_chestplate", "lv_te:titanium_leggings", "lv_te:titanium_boots"];
            const steelSet = ["lv_te:steel_helmet", "lv_te:steel_chestplate", "lv_te:steel_leggings", "lv_te:steel_boots"];
            const fullSetBonus = [
                { set: titaniumSet, tag: "wearing_full_titanium_armor", effect: "strength" },
                { set: steelSet, tag: "wearing_full_steel_armor", effect: "speed" }
            ];

            for (const { set, tag, effect } of fullSetBonus) {
                const isWearingFullSet = set.every(typeId => {
                    const slot = EquippableEffects.getSlotForType(typeId);
                    const item = equipComponent.getEquipment(slot);
                    return item && item.typeId === typeId;
                });

                if (isWearingFullSet) {
                    EquippableEffects.applyEffectWithTag(player, tag, effect, 11, 0);
                } else {
                    EquippableEffects.removeEffectWithTag(player, tag, effect);
                }
            }
        }
    }
}
