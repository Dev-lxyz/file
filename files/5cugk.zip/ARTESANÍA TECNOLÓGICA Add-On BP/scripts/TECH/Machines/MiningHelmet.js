import { system, world, EntityComponentTypes, EquipmentSlot } from '@minecraft/server';

export class MiningHelmet {
    static initialize() {
        system.runInterval(() => {
            MiningHelmet.runMiningHelmet();
        }, 1); // Run every tick
    }

    static runMiningHelmet() {
        // Iterate through all players in the world
        for (const player of world.getPlayers()) {
            if (!player || !player.getComponent(EntityComponentTypes.Equippable)) continue;

            // Get the equippable component
            const equipComponent = player.getComponent(EntityComponentTypes.Equippable);

            // Check if the player is wearing the mining helmet
            if (equipComponent.getEquipment(EquipmentSlot.Head)?.typeId === 'lv_te:mining_helmet') {
                const playerPos = player.location;
                
                // Get the block at the player's position
                const blockAbove = world.getDimension(player.dimension.id).getBlock({
                    x: Math.floor(playerPos.x),
                    y: Math.floor(playerPos.y) + 1,
                    z: Math.floor(playerPos.z)
                });

                // Place the custom light block if the position is air
                if (blockAbove?.typeId === "minecraft:air" || blockAbove?.typeId === "lv_te:custom_light") {
                    blockAbove.setType("lv_te:custom_light");
                }
            }
        }
    }

    onTick(event) {
        event.block // Block impacted by this event.
        event.dimension // Dimension that contains the block.
    }
}
