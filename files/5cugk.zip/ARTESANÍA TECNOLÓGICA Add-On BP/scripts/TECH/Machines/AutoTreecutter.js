import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import * as MC from '../MachinesConstants.js';
import { MachineClass } from '../MachineClass.js';

export class AutoTreecutter {
    static initialize() {
        let worldReady = false;

        const checkWorldReady = () => {
            const overworld = world.getDimension("overworld");
            if (overworld.getPlayers().length > 0) {
                worldReady = true;
                AutoTreecutter.resetAllMachines();
            } else {
                system.runTimeout(checkWorldReady, 20); // Check again after 10 ticks
            }
        };

        // Start checking for world readiness
        checkWorldReady();

        // Periodically check machines
        system.runInterval(() => {
            AutoTreecutter.runAutoTreecutter();
        }, 20); // Run every second
    }


    static runAutoTreecutter() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:auto_treecutter");


            // Process each machine
            for (const machine of entities) {
                AutoTreecutter.attemptGrowTree(machine);
            }
        }
    }

    // Helper function to add items to inventory
    static addItemToInventory(inventory, itemStack) {
        try {
            for (let i = 0; i < inventory.size; i++) {
                const currentItem = inventory.getItem(i);
                if (!currentItem) {
                    inventory.setItem(i, itemStack);
                    return true;
                }
                if (currentItem.typeId === itemStack.typeId && currentItem.amount < currentItem.maxAmount) {
                    const spaceLeft = currentItem.maxAmount - currentItem.amount;
                    const amountToAdd = Math.min(spaceLeft, itemStack.amount);
                    currentItem.amount += amountToAdd;
                    inventory.setItem(i, currentItem);
                    return amountToAdd === itemStack.amount;
                }
            }
            return false;
        } catch (error) {

        }

    }

    static resetAllMachines() {
        const dimensions = ["overworld", "nether", "the_end"];

        system.runTimeout(() => {
            // Iterate through each dimension
            for (const dimensionName of dimensions) {
                const dimension = world.getDimension(dimensionName);
                if (!dimension) continue;

                // Get all machines in the dimension
                const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:auto_treecutter");

                // Process each machine
                for (const machine of entities) {
                    if (machine.getProperty("lv_te:grow_tree") == 1) {
                        machine.setProperty("lv_te:grow_tree", 0);
                    }
                }
            }
        }, 40);


    }


    static runAutoTreecutter() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:auto_treecutter");

            // Process each machine
            for (const machine of entities) {
                AutoTreecutter.attemptGrowTree(machine);
            }
        }
    }

    static attemptGrowTree(machine) {
        try {
            const inventoryComponent = machine.getComponent("minecraft:inventory");
            if (!inventoryComponent) return;

            const inventory = inventoryComponent.container;
            const saplingType = machine.getProperty("lv_te:sapling");

            if (saplingType === 0) return; // No sapling placed

            const growTreeState = machine.getProperty("lv_te:grow_tree");

            if (growTreeState === 2) {
                const machineConfig = MC.machineConfigs[machine.typeId];
                // Check if machine has enough fuel (if required)
                if (machineConfig.fuelUsage > 0) {
                    const hasFuel = MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage, true);
                    if (!hasFuel) {
                        //console.warn(`Machine ${machine.typeId} is out of fuel.`);
                        return;
                    }
                }
                // Harvest the tree using a custom loot table system
                const lootTable = AutoTreecutter.getLootTableForSapling(saplingType);

                for (const item of lootTable) {
                    const dropCount = Math.floor(Math.random() * (item.maxCount - item.minCount + 1)) + item.minCount; // Random between minCount and maxCount
                    if (dropCount > 0) {
                        const drop = new ItemStack(item.type, dropCount);
                        AutoTreecutter.addItemToInventory(inventory, drop);
                    }
                }
                MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage);

                machine.setProperty("lv_te:grow_tree", 0); // Reset grow_tree state
            } else if (growTreeState === 0) {
                // Start growing the tree
                machine.setProperty("lv_te:grow_tree", 1);

                system.runTimeout(() => {
                    try {
                        machine.setProperty("lv_te:grow_tree", 2); // Set to fully grown
                    } catch (error) {

                    }
                }, 400); // 20 seconds
            }
        } catch (error) {
            //console.error(`Error while growing tree: ${error}`);
        }
    }

    static getLootTableForSapling(saplingType) {
        switch (saplingType) {
            case 1: // Oak tree
                return [
                    { type: "minecraft:oak_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:oak_sapling", minCount: 0, maxCount: 2 },
                    { type: "minecraft:apple", minCount: 0, maxCount: 1 }
                ];
            case 2: // Spruce tree
                return [
                    { type: "minecraft:spruce_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:spruce_sapling", minCount: 0, maxCount: 2 }
                ];
            case 3: // Birch tree
                return [
                    { type: "minecraft:birch_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:birch_sapling", minCount: 0, maxCount: 2 }
                ];
            case 4: // Jungle tree
                return [
                    { type: "minecraft:jungle_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:jungle_sapling", minCount: 0, maxCount: 2 },
                    { type: "minecraft:cocoa_beans", minCount: 0, maxCount: 1 }
                ];
            case 5: // Acacia tree
                return [
                    { type: "minecraft:acacia_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:acacia_sapling", minCount: 0, maxCount: 2 }
                ];
            case 6: // Dark Oak tree
                return [
                    { type: "minecraft:dark_oak_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:dark_oak_sapling", minCount: 0, maxCount: 2 },
                    { type: "minecraft:apple", minCount: 0, maxCount: 1 }
                ];
            case 7: // Pale Oak tree
                return [
                    { type: "minecraft:pale_oak_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:pale_oak_sapling", minCount: 0, maxCount: 2 }
                ];
            case 8: // Cherry tree
                return [
                    { type: "minecraft:cherry_log", minCount: 1, maxCount: 5 },
                    { type: "minecraft:cherry_sapling", minCount: 0, maxCount: 2 },
                    { type: "minecraft:pink_petals", minCount: 0, maxCount: 3 }
                ];
            default:
                return [];
        }
    }

}
