import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';

export class Sara {
    static initialize() {
        // Periodically check machines
        system.runInterval(() => {
            Sara.runSara();
        }, 20); // Run every second
    }


    static runSara() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:sara");


            // Process each machine
            for (const machine of entities) {
                Sara.attemptPickUpItem(machine);
            }
        }
    }

    static attemptPickUpItem(machine) {
        // Get the machine's position
        const position = machine.location;
        const dimension = machine.dimension;

        // Define the search range
        const range = 4;

        // Find nearby items
        const items = dimension.getEntities({
            type: "minecraft:item",
            location: position,
            maxDistance: range,
        });

        // Get the machine's inventory
        const inventory = machine.getComponent("minecraft:inventory");
        if (!inventory) return;

        const container = inventory.container;

        for (const itemEntity of items) {
            const itemComponent = itemEntity.getComponent("minecraft:item");
            if (!itemComponent) continue;

            const itemStack = itemComponent.itemStack;
            if (!itemStack) continue;

            // Track how much of the item remains to be picked up
            let remainingAmount = itemStack.amount;

            // Try to merge with existing stacks
            for (let i = 0; i < container.size; i++) {
                const slot = container.getItem(i);
                if (slot && slot.typeId === itemStack.typeId && slot.amount < slot.maxAmount) {
                    const transferAmount = Math.min(remainingAmount, slot.maxAmount - slot.amount);
                    slot.amount += transferAmount;
                    remainingAmount -= transferAmount;

                    container.setItem(i, slot);

                    if (remainingAmount <= 0) break;
                }
            }

            // Try to place in an empty slot
            if (remainingAmount > 0) {
                for (let i = 0; i < container.size; i++) {
                    const slot = container.getItem(i);
                    if (!slot) {
                        //set all Components of the new item to all of the components of the old one 
                        const newStack = itemStack.clone();
                        container.setItem(i, newStack);
                        remainingAmount = 0;
                        break;
                    }
                }
            }

            // If all items were picked up, remove the entity
            if (remainingAmount <= 0) {
                itemEntity.kill();
                machine.runCommandAsync('playsound random.pop @a ~~~');
            } else {
                try {
                    
                // Update the item entity with the remaining amount
                //set all Components of the new item to all of the components of the old one
                const updatedStack = itemStack.clone();
                itemEntity.getComponent("minecraft:item").itemStack = updatedStack;
                } catch (error) {
                    
                }
            }
        }
    }


}
