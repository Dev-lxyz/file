import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';

export class OilExtractor {

    static initialize() {
        system.runInterval(() => {
            OilExtractor.runOilExtractor();
        }, 60); // Run every 3 seconds
    }


    static runOilExtractor() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:oil_extractor");

            // Process each machine
            for (const machine of entities) {
                OilExtractor.addOil(machine, dimension);
            }
        }
    }

    static addOil(machine, dimension) {
        try {
            const inventoryComponent = machine.getComponent("minecraft:inventory");
    
            if (!inventoryComponent) {
                return;
            }
    
            const inventory = inventoryComponent.container;
            const oilItem = new ItemStack("lv_te:oil", 1);
    
            let hasSpace = false;
    
            // Check for space in the inventory
            for (let i = 0; i < inventory.size; i++) {
                const currentItem = inventory.getItem(i);
    
                if (!currentItem) {
                    // Empty slot found
                    hasSpace = true;
                    break;
                }
    
                if (currentItem.typeId === "lv_te:oil" && currentItem.amount < currentItem.maxAmount) {
                    // Existing oil stack has space
                    hasSpace = true;
                    break;
                }
            }
    
            if (hasSpace) {
                // Add oil to the first available slot or stack
                for (let i = 0; i < inventory.size; i++) {
                    const currentItem = inventory.getItem(i);
    
                    if (!currentItem) {
                        // Empty slot found, add the oil
                        inventory.setItem(i, oilItem);
                        break;
                    }
    
                    if (currentItem.typeId === "lv_te:oil" && currentItem.amount < currentItem.maxAmount) {
                        // Add to an existing oil stack
                        const spaceLeft = currentItem.maxAmount - currentItem.amount;
                        const amountToAdd = Math.min(spaceLeft, 1); // Add one item
    
                        currentItem.amount += amountToAdd;
                        inventory.setItem(i, currentItem);
                        break;
                    }
                }
    
                // Ensure the "is_full" property is false when there is space
                machine.setProperty("lv_te:is_full", false);
            } else {
                // No space available, set the "is_full" property
                machine.setProperty("lv_te:is_full", true);
            }
        } catch (error) {
            console.error("Error adding oil to the machine:", error);
        }
    }    
}
