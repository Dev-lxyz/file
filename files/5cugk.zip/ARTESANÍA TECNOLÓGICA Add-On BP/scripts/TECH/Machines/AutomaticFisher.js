import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import * as MC from '../MachinesConstants.js';

export class AutomaticFisher {

    static initialize() {
        system.runInterval(() => {
            AutomaticFisher.runAutomaticFisher();
        }, 300);
    }


    static runAutomaticFisher() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:automatic_fisher");

            // Process each machine
            for (const machine of entities) {
                AutomaticFisher.tryCatchFish(machine, dimension);
            }
        }
    }

    static tryCatchFish(machine, dimension) {
    
        const inventoryComponent = machine.getComponent("minecraft:inventory");
        if (!inventoryComponent) return;
    
        const inventory = inventoryComponent.container;
    
        // Helper function to add item to inventory
        function addItemToInventory(itemStack) {
            for (let i = 0; i < inventory.size; i++) {
                const currentItem = inventory.getItem(i);
                if (!currentItem) {
                    inventory.setItem(i, itemStack);
                    return true;
                }
                if (currentItem.typeId === itemStack.typeId && currentItem.amount < currentItem.maxAmount) {
                    const spaceLeft = currentItem.maxAmount - currentItem.amount;
                    const amountToAdd = Math.min(spaceLeft, itemStack.amount);
                    currentItem.amount += amountToAdd;
                    inventory.setItem(i, currentItem);
                    return amountToAdd === itemStack.amount;
                }
            }
            return false;
        }
    
        // Weighted random selection function
        function selectRandomFish() {
            const totalWeight = MC.FISH_CATCH_WEIGHTS.reduce((sum, fish) => sum + fish.weight, 0);
            let random = Math.random() * totalWeight;
            for (const fish of MC.FISH_CATCH_WEIGHTS) {
                if (random < fish.weight) return fish.name;
                random -= fish.weight;
            }
        }
    
        const machinePosition = machine.location;
        const blockBelowMachine = dimension.getBlock({
            x: machinePosition.x,
            y: machinePosition.y - 1,
            z: machinePosition.z
        });
    
        // Ensure the block below the machine is water
        if (!blockBelowMachine || blockBelowMachine.typeId !== "minecraft:water") return;
    
        let caughtFish = false;
    
        // Check the 3x3 area below the machine
        for (let x = -1; x <= 1; x++) {
            for (let z = -1; z <= 1; z++) {
                const waterBlockPos = {
                    x: machinePosition.x + x,
                    y: machinePosition.y - 1,
                    z: machinePosition.z + z
                };
    
                const block = dimension.getBlock(waterBlockPos);
                if (block && block.typeId === "minecraft:water" && Math.random() < 0.05) {
                    const fishType = selectRandomFish();
                    const fishItemStack = new ItemStack(fishType, 1);
                    if (addItemToInventory(fishItemStack)) {
                        caughtFish = true;
                    }
                }
            }
        }
    
        // Play a sound if at least one fish was caught
        if (caughtFish) {
            dimension.runCommandAsync(
                `playsound random.splash @a ${machinePosition.x} ${machinePosition.y} ${machinePosition.z}`
            );
        }

    }
}
