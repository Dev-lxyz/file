import { system, world, BlockInventoryComponent, ItemStack } from '@minecraft/server';
import { MachineClass } from '../MachineClass.js';
import * as MC from '../MachinesConstants.js';

export class Pipes {
    static initialize() {
        system.runInterval(() => {
            Pipes.runPipes();
        }, 20); // Run every second
    }

    static runPipes() {
        const dimensions = ["overworld", "nether", "the_end"];

        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:pipe_dummy");

            for (const pipe of entities) {
                if (pipe.getProperty('lv_te:input')) {
                    if (pipe.getProperty('lv_te:type') == 1) {
                        Pipes.inputItem(pipe, dimension, 4);
                    } else {
                        Pipes.inputItem(pipe, dimension, 2);
                    }
                }
                if (pipe.getProperty('lv_te:output')) {
                    if (pipe.getProperty('lv_te:type') == 1) {
                        Pipes.outputItem(pipe, dimension, 4);
                    } else {
                        Pipes.outputItem(pipe, dimension, 2);
                    }
                }
            }
        }
    }

    static inputItem(pipe, dimension, transferAmount) {
        const pipeInventory = pipe.getComponent("inventory").container;
        if (!pipeInventory) return;

        // Check adjacent block inventory
        const blockInventory = this.getAdjacentInventory(pipe, dimension, true);
        if (blockInventory) {
            this.transferItems(blockInventory, pipeInventory, transferAmount, pipe);
            return;
        }

        // Check adjacent entity inventory
        const entityInventory = this.getAdjacentEntityInventory(pipe, dimension, "lv_te:pipe_dummy");
        if (entityInventory) {

            this.transferItems(entityInventory, pipeInventory, transferAmount, pipe);
            return;
        }
    }

    static outputItem(pipe, dimension, transferAmount) {
        const pipeInventory = pipe.getComponent("inventory").container;
        if (!pipeInventory) return;
        // Check adjacent block inventory
        const blockInventory = this.getAdjacentInventory(pipe, dimension, false);
        if (blockInventory) {
            this.transferItems(pipeInventory, blockInventory, transferAmount, pipe);
            return;
        }

        // Check adjacent entity inventory
        const entityInventory = this.getAdjacentEntityInventoryOutput(pipe, dimension);
        if (entityInventory) {

            this.transferItems(pipeInventory, entityInventory, transferAmount, pipe);
            return;
        }
    }

    static transferItems(sourceInventory, targetInventory, maxTransfer, sourceEntity) {
        let itemTransferred = false;

        for (let i = 0; i < sourceInventory.size; i++) {
            const item = sourceInventory.getItem(i);
            if (item && this.hasSpace(targetInventory, item)) {
                const transferAmount = Math.min(maxTransfer, item.amount);
                const remainingAmount = item.amount - transferAmount;

                // Clone the item to preserve all properties
                const transferredItem = item.clone();
                transferredItem.amount = transferAmount;

                // Create a new placeholder item for the remaining amount
                const remainingItem = remainingAmount > 0 ? item.clone() : null;
                if (remainingItem) {
                    remainingItem.amount = remainingAmount;
                }

                // Update source inventory
                sourceInventory.setItem(i, remainingItem);

                // Add the transferred item to the target inventory
                this.addItemToContainer(targetInventory, transferredItem);

                itemTransferred = true;
                break; // Transfer only up to the maximum allowed
            }
        }

        if (sourceEntity) {
            let pipeBlock = sourceEntity.dimension.getBlock(sourceEntity.location);
            let newBlockPermutation = pipeBlock.permutation;

            if (itemTransferred) {
                // Set has_items to true
                newBlockPermutation = newBlockPermutation.withState("lv_te:has_items", true);
                pipeBlock.setPermutation(newBlockPermutation);

                // Store the timeout ID in a Map, using the pipe's unique position as a key
                const pipeLocationKey = `${sourceEntity.location.x},${sourceEntity.location.y},${sourceEntity.location.z}`;
                if (!this._resetTimeoutMap) {
                    this._resetTimeoutMap = new Map();
                }

                // Clear any existing timeout for this pipe
                if (this._resetTimeoutMap.has(pipeLocationKey)) {
                    system.clearRun(this._resetTimeoutMap.get(pipeLocationKey));
                }

                // Set a new timeout for this pipe
                const timeoutId = system.runTimeout(() => {
                    try {

                        const blockPermutation = pipeBlock.permutation.withState("lv_te:has_items", false);
                        pipeBlock.setPermutation(blockPermutation);
                        this._resetTimeoutMap.delete(pipeLocationKey); // Clean up the map entry
                    } catch (error) {

                    }
                }, 40); // 2 second delay = 40 ticks

                // Store the timeout ID
                this._resetTimeoutMap.set(pipeLocationKey, timeoutId);
            }
        }
    }

    // Helper function to convert block_face to block_face
    static facingDirectionToBlockFace(facingDirection) {
        const conversionMap = {
            'north': 'south',
            'south': 'north',
            'east': 'west',
            'west': 'east',
            'up': 'down',
            'down': 'up'
        };

        return conversionMap[facingDirection] || facingDirection;
    }
    // Helper method to check if an inventory still has transferable items
    static hasItemsInInventory(inventory) {
        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (item) {
                return true; // Found at least one item
            }
        }
        return false; // No items found
    }

    static hasSpace(container, item) {
        for (let i = 0; i < container.size; i++) {
            const slotItem = container.getItem(i);

            // Check for an empty slot
            if (!slotItem) {
                return true; // Empty slot available
            }

            // Check if the slot can accommodate more of the same item
            if (
                slotItem.typeId === item.typeId &&
                slotItem.amount < slotItem.maxAmount
            ) {
                return true; // Space available in this slot
            }
        }

        // No space found
        return false;
    }


    static addItemToContainer(container, item) {
        let amountPlaceholder = item.amount;
        for (let i = 0; i < container.size; i++) {
            const slotItem = container.getItem(i);


            if (!slotItem) {
                // Add the item directly to an empty slot
                const newItem = item.clone(); // Clone to preserve properties
                container.setItem(i, newItem);
                return;
            }

            if (slotItem.typeId === item.typeId && slotItem.amount < slotItem.maxAmount) {
                const space = slotItem.maxAmount - slotItem.amount;
                const transferAmount = Math.min(space, amountPlaceholder);

                // Clone the existing slot item to preserve properties
                const updatedSlotItem = slotItem.clone();
                updatedSlotItem.amount += transferAmount;
                container.setItem(i, updatedSlotItem);

                // Adjust the input item's amount
                amountPlaceholder -= transferAmount;
                1
                // If all items have been transferred, we're done
                if (amountPlaceholder <= 0) return;
            }
        }

        // If we exit the loop and still have items left, there's no space in the container
    }


    // Updated getAdjacentInventory method using block_face instead of block_face
    static getAdjacentInventory(pipeEntity, dimension, isInput) {
        try {
            // Get the block where the pipe is located
            const pipeBlock = dimension.getBlock(pipeEntity.location);

            // Get the block face (the face that was clicked when placing)
            const blockFace = pipeBlock.permutation.getState("minecraft:block_face");

            // Map of block faces to offsets (where the pipe connects to)
            const blockFaceOffsets = {
                north: { x: 0, y: 0, z: 1 },
                south: { x: 0, y: 0, z: -1 },
                east: { x: -1, y: 0, z: 0 },
                west: { x: 1, y: 0, z: 0 },
                up: { x: 0, y: -1, z: 0 },
                down: { x: 0, y: 1, z: 0 },
            };

            // Get the offset for the current block face
            let offset = blockFaceOffsets[blockFace];
            if (!offset) {
                return null;
            }

            // Reverse the offset if we are looking for an output block
            if (!isInput) {
                offset = { x: -offset.x, y: -offset.y, z: -offset.z };

            }

            // Calculate the adjacent block location
            const adjacentBlockLocation = {
                x: pipeEntity.location.x + offset.x,
                y: pipeEntity.location.y + offset.y,
                z: pipeEntity.location.z + offset.z,
            };

            // Get the adjacent block
            const adjacentBlock = dimension.getBlock(adjacentBlockLocation);

            if (!adjacentBlock) {
                return null;
            }

            // Check if the adjacent block is a valid container
            if (!MC.validContainers.includes(adjacentBlock.typeId)) {
                return null;
            }

            // Get the inventory component of the adjacent block
            const inventoryComponent = adjacentBlock.getComponent("minecraft:inventory");
            if (!inventoryComponent) {
                return null;
            }

            // Return the inventory container
            return inventoryComponent.container;
        } catch (error) {
            return null;
        }
    }
    static invertDirection(dir) {
        const map = {
            north: "south",
            south: "north",
            east: "west",
            west: "east",
            up: "down",
            down: "up",
        };
        return map[dir];
    }
    static directionToOffsetFromString(dir) {
        const offsets = {
            north: { x: 0, y: 0, z: -1 },
            south: { x: 0, y: 0, z: 1 },
            east: { x: 1, y: 0, z: 0 },
            west: { x: -1, y: 0, z: 0 },
            up: { x: 0, y: 1, z: 0 },
            down: { x: 0, y: -1, z: 0 },
        };
        return offsets[dir] ?? { x: 0, y: 0, z: 0 };
    }

    static getAdjacentEntityInventory(pipeEntity, dimension) {
        try {
            const pipeBlock = dimension.getBlock(pipeEntity.location);
            const faceId = pipeBlock.permutation.getState("minecraft:block_face");
            const facing = typeof faceId === "number" ? this.faceIdToName(faceId) : faceId;
            const inputDirection = this.invertDirection(facing);

            const offset = this.directionToOffsetFromString(inputDirection);
            if (!offset) return null;

            const adjacentLocation = {
                x: pipeEntity.location.x + offset.x,
                y: pipeEntity.location.y + offset.y,
                z: pipeEntity.location.z + offset.z,
            };

            const entities = dimension.getEntitiesAtBlockLocation(adjacentLocation);
            for (const entity of entities) {
                if (MC.pipeBlocks.includes(entity.typeId)) continue;
                if (entity.typeId == "minecraft:player") continue;

                const inventoryComponent = entity.getComponent("minecraft:inventory")?.container;
                if (inventoryComponent) return inventoryComponent;
            }

            return null;
        } catch (error) {
            return null;
        }
    }

    //Output Basically should check the facing direction neighbor
    static getAdjacentEntityInventoryOutput(pipeEntity, dimension) {
        try {
            const pipeBlock = dimension.getBlock(pipeEntity.location);
            const faceId = pipeBlock.permutation.getState("minecraft:block_face");
            const facing = typeof faceId === "number" ? this.faceIdToName(faceId) : faceId;

            const facingOffsets = {
                north: { x: 0, y: 0, z: -1 },
                south: { x: 0, y: 0, z: 1 },
                east: { x: -1, y: 0, z: 0 },
                west: { x: 1, y: 0, z: 0 },
                up: { x: 0, y: -1, z: 0 },
                down: { x: 0, y: 1, z: 0 },
            };

            const offset = facingOffsets[facing];
            if (!offset) return null;

            const adjacentLocation = {
                x: pipeEntity.location.x + offset.x,
                y: pipeEntity.location.y + offset.y,
                z: pipeEntity.location.z + offset.z,
            };

            const entities = dimension.getEntitiesAtBlockLocation(adjacentLocation);

            for (const entity of entities) {
                if (MC.pipeBlocks.includes(entity.typeId)) continue;
                if (entity.typeId == "minecraft:player") continue;
                if (entity.typeId == "lv_te:pipe_dummy") continue;

                const inventoryComponent = entity.getComponent("minecraft:inventory")?.container;

                if (inventoryComponent) return inventoryComponent;
            }

            return null;
        } catch (error) {
            return null;
        }
    }
}
