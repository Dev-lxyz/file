import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import * as MC from '../MachinesConstants.js';

export class AutomaticHarvester {

    static initialize() {
        system.runInterval(() => {
            AutomaticHarvester.runAutomaticHarvester();
        }, 20);
    }


    static runAutomaticHarvester() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:automatic_harvester");

            // Process each machine
            for (const machine of entities) {
                AutomaticHarvester.harvestCrops(machine, dimension);
            }
        }
    }

    static harvestCrops(machine, dimension) {
        const inventoryComponent = machine.getComponent("minecraft:inventory");


        if (!inventoryComponent) {
            return;
        }


        const inventory = inventoryComponent.container;

        // Helper function to check inventory space and add item
        function addItemToInventory(itemStack) {
            for (let i = 0; i < inventory.size; i++) {
                const currentItem = inventory.getItem(i);

                if (!currentItem) {
                    // Empty slot found
                    inventory.setItem(i, itemStack);
                    return true;
                }

                if (currentItem.typeId === itemStack.typeId && currentItem.amount < currentItem.maxAmount) {
                    // Add to an existing stack
                    const spaceLeft = currentItem.maxAmount - currentItem.amount;
                    const amountToAdd = Math.min(spaceLeft, itemStack.amount);
                    const updatedItemStack = new ItemStack(itemStack.typeId, amountToAdd);
                    currentItem.amount += updatedItemStack.amount;
                    inventory.setItem(i, currentItem);

                    if (amountToAdd === itemStack.amount) {
                        return true;
                    }
                }
            }

            return false; // No space available
        }

        const machinePosition = machine.location;

        // Iterate through the 3x3 area with a -1 y offset
        for (let x = -3; x <= 3; x++) {
            for (let z = -3; z <= 3; z++) {
                const cropPosition = {
                    x: machinePosition.x + x,
                    y: machinePosition.y - 1,
                    z: machinePosition.z + z
                };

                const block = dimension.getBlock(cropPosition);
                if (!block) continue;

                // Check if the block is harvestable
                const harvestable = MC.HarvestableBlocks.find(h => h.blockType === block.typeId);
                if (!harvestable) continue;

                // Check if the crop is fully grown
                let growthStage = block.permutation.getState("growth");
                if (block.typeId === "minecraft:cocoa") {
                    growthStage = block.permutation.getState("age");   
                }
                if (harvestable.maxGrowthStage !== undefined && growthStage < harvestable.maxGrowthStage) {
                    continue;
                }

                // Attempt to add outcomes to the inventory
                let canHarvest = true;
                for (const outcome of harvestable.outcomes) {
                    const itemStack = new ItemStack(outcome.itemType, outcome.quantity);
                    if (!addItemToInventory(itemStack)) {
                        canHarvest = false;
                        break;
                    }
                }

                if (canHarvest) {
                    // Replace with seed if defined
                    if (harvestable.seeds) {
                        dimension.setBlockType(cropPosition, "minecraft:air");
                        dimension.setBlockType(cropPosition, harvestable.seeds);
                    } else {
                        dimension.setBlockType(cropPosition, "minecraft:air");
                    }
                    dimension.runCommandAsync(`playsound dig.grass @a ${cropPosition.x} ${cropPosition.y} ${cropPosition.z}`);
                }
            }
        }

    }
}
