import { system, world, EntityComponentTypes, EquipmentSlot } from '@minecraft/server';

export class TechJetpack {
    static initialize() {
        system.runInterval(() => {
            this.runTechJetpack();
        }, 1); // Run every tick
    }

    static runTechJetpack() {
        for (const player of world.getPlayers()) {
            if (!player || !player.getComponent(EntityComponentTypes.Equippable)) continue;

            const equipComponent = player.getComponent(EntityComponentTypes.Equippable);

            // Check if the player is wearing the tech jetpack
            if (equipComponent.getEquipment(EquipmentSlot.Chest)?.typeId === 'lv_te:tech_jetpack') {
                let flying = false;


                let fuel = player.getDynamicProperty('jetpackFuel');
                let wasFlying = player.getDynamicProperty('wasFlying');
                let hasSlowFalling = player.getDynamicProperty('hasSlowFalling');

                // Handle flight logic
                if (player.isSneaking && fuel > 0) {
                    flying = true;
                    fuel = Math.max(fuel - 4, 0); // Reduce fuel while flying

                    // Get the player's rotation (yaw and pitch)
                    const rotation = player.getRotation(); // Assuming getRotation gives yaw and pitch in degrees

                    const yaw = (rotation.y * Math.PI) / 180; // Convert yaw to radians
                    const knockbackX = -Math.sin(yaw); // Forward direction on X-axis
                    const knockbackZ = Math.cos(yaw);  // Forward direction on Z-axis
                    const upwardStrength = 0.7;       // Slight upward boost
                    const horizontalStrength = 1.1;  // Boost strength for forward direction

                    // Apply knockback to the player
                    player.applyKnockback(knockbackX, knockbackZ, horizontalStrength, upwardStrength);
                    player.runCommand(`particle lv_te:boosting_pad ${player.location.x} ${player.location.y+0.3} ${player.location.z}`);
                    player.runCommand(`playsound firework.launch @a ${player.location.x} ${player.location.y} ${player.location.z} 0.15 1.05 0.001`);
                    // Mark the player as flying
                    wasFlying = true;

                    // Apply levitation effect for upward thrust
                    player.addEffect("levitation", 10, { amplifier: 5, showParticles: false });
                } else if (player.isFalling && !hasSlowFalling && wasFlying) {
                    // Apply slow falling effect only if the player was flying
                    player.addEffect("slow_falling", 300, { amplifier: 0, showParticles: false });
                    player.setDynamicProperty('hasSlowFalling', true);
                } else if (player.isOnGround) {
                    // Remove slow falling effect and reset the state when on the ground
                    player.removeEffect("slow_falling");
                    player.setDynamicProperty('hasSlowFalling', false);

                    // Recharge fuel while on the ground
                    fuel = Math.min(fuel + 2, 100); // Recharge rate

                    // Reset flying state
                    wasFlying = false;
                } else {
                    // Remove levitation effect when not actively flying
                    player.removeEffect("levitation");
                }

                // Update dynamic properties
                player.setDynamicProperty('jetpackFuel', fuel);
                player.setDynamicProperty('wasFlying', wasFlying);

                // Show fuel bar in the action bar
                player.onScreenDisplay.setActionBar(`§8[§6Fuel§8]§e ${fuel}`);
            }
        }
    }
}
