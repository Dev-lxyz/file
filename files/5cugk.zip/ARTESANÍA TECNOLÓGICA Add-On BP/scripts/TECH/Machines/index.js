import {OilExtractor} from './OilExtractor.js';
import {OreGenerator} from './OreGenerator.js';
import {AutomaticDrill} from './AutomaticDrill.js';
import {AutomaticHarvester} from './AutomaticHarvester.js';
import {AutomaticFisher} from './AutomaticFisher.js';
import {AutoTreecutter} from './AutoTreecutter.js';
import {Pipes} from './Pipes.js';
import {EquippableEffects} from './EquippableEffects.js';
import {MiningHelmet} from './MiningHelmet.js';
import {TechJetpack} from './TechJetpack.js';
import {Sara} from './Sara.js';
import {Fred} from './Fred.js';
import {HoldingPipes} from './HoldingPipes.js';

export class index {
    static initializeAll() {
        OilExtractor.initialize();
        OreGenerator.initialize();
        AutomaticDrill.initialize();
        AutomaticHarvester.initialize();
        AutomaticFisher.initialize();
        AutoTreecutter.initialize();
        Pipes.initialize();
        EquippableEffects.initialize();
        MiningHelmet.initialize();
        TechJetpack.initialize();
        Sara.initialize();
        Fred.initialize();
        HoldingPipes.initialize();
    }
}
