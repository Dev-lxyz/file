import { system, world} from '@minecraft/server';

export class HoldingPipes {

    static initialize() {
        // Use runInterval to avoid overlapping executions
        system.runInterval(() => {
            HoldingPipes.runHoldingPipes();
        }, 20);
    }

    static runHoldingPipes() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all players in the dimension
            const entities = dimension.getEntities().filter(entity =>
                entity.typeId === "minecraft:player"
            );

            // Process each player
            for (const player of entities) {
                HoldingPipes.checkItemInHand(player, dimension);
            }
        }
    }

    static checkItemInHand(player, dimension) {
        // Get the item in the player's main hand
        const heldItem = player.getComponent("minecraft:inventory")?.container.getItem(player.selectedSlotIndex);

        if (!heldItem) return;

        // Check if the item is either lv_te:copper_pipe or lv_te:advanced_pipe
        if (heldItem.typeId === "lv_te:copper_pipe" || heldItem.typeId === "lv_te:advanced_pipe") {
            // Find entities within a 6-block radius with the family tag lv_te.pipe_tooltip
            const nearbyEntities = dimension.getEntities({
                location: player.location,
                maxDistance: 6,
                families: ["lv_te.pipe_tooltip"],
            });

            // Play animation for these entities
            for (const entity of nearbyEntities) {
                entity.playAnimation("animation.lv_te.static.pipe_tooltip");
            }
        }
    }
}
