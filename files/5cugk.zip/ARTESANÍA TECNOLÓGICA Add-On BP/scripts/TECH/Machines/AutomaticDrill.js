import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import { MachineClass } from '../MachineClass.js';
import * as MC from '../MachinesConstants.js';

export class AutomaticDrill {

    static initialize() {
        // Use runInterval to avoid overlapping executions
        system.runInterval(() => {
            AutomaticDrill.runAutomaticDrill();
        }, 5); // Runs every tick
    }

    static runAutomaticDrill() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity =>
                entity.typeId === "lv_te:automatic_drill" || entity.typeId === "lv_te:advanced_automatic_drill"
            );

            // Process each machine
            for (const machine of entities) {
                AutomaticDrill.checkBlock(machine, dimension);
            }
        }
    }

    static checkBlock(machine, dimension) {
        const blockBelow = dimension.getBlock({ x: machine.location.x, y: machine.location.y - 1, z: machine.location.z });
        if (!blockBelow) return;
        

        // Check if the block is in DrillableBlocks
        const drillable = MC.DrillableBlocks.find(drillableBlock => drillableBlock.blockType === blockBelow.typeId);
        if (!drillable) return;

        // Wait 2 seconds before breaking the block
        if (!machine.getProperty("lv_te:drill_timer")) {
            machine.resetProperty("lv_te:drill_timer"); // 40 ticks = 2 seconds
        } else {
            const timer = machine.getProperty("lv_te:drill_timer") - 5;
            if (timer <= 0) {
                AutomaticDrill.breakBlock(machine, dimension, blockBelow, drillable);
                machine.resetProperty("lv_te:drill_timer");
            } else {
                machine.setProperty("lv_te:drill_timer", timer);
            }
        }
    }

    static breakBlock(machine, dimension, blockBelow, drillable) {
        // Ensure the block is still the same before breaking it
        const currentBlock = dimension.getBlock({ x: blockBelow.location.x, y: blockBelow.location.y, z: blockBelow.location.z });
        if (!currentBlock || currentBlock.typeId !== blockBelow.typeId) return;

        // Access the inventory component
        const inventoryComponent = machine.getComponent("minecraft:inventory");
        if (!inventoryComponent) return;

        const inventory = inventoryComponent.container;
        let hasSpace = false;

        // Check for space in the inventory
        for (let i = 0; i < inventory.size; i++) {
            const currentItem = inventory.getItem(i);

            if (!currentItem) {
                // Empty slot found
                hasSpace = true;
                break;
            }

            if (currentItem.typeId === drillable.outcomes[0].itemType && currentItem.amount < currentItem.maxAmount) {
                // Existing stack of the same type with space
                hasSpace = true;
                break;
            }
        }

        if (!hasSpace) {
            // No space available, stop processing
            return;
        }

        // Remove the block
        blockBelow.setType("minecraft:air");

        // Add the outcome items to the drill's inventory
        for (const outcome of drillable.outcomes) {
            const itemStack = new ItemStack(outcome.itemType, outcome.quantity);

            let added = false;
            // Add items to the first available slot or stack
            for (let i = 0; i < inventory.size; i++) {
                const currentItem = inventory.getItem(i);

                if (!currentItem) {
                    // Empty slot found, add the item
                    inventory.setItem(i, itemStack);
                    added = true;
                    break;
                }

                if (currentItem.typeId === outcome.itemType && currentItem.amount < currentItem.maxAmount) {
                    // Add to an existing stack with space
                    const spaceLeft = currentItem.maxAmount - currentItem.amount;
                    const amountToAdd = Math.min(spaceLeft, outcome.quantity);

                    currentItem.amount += amountToAdd;
                    inventory.setItem(i, currentItem);
                    added = true;
                    break;
                }
            }

            if (!added) {
                // Drop the item in the world if it cannot be added to inventory
                const dropLocation = {
                    x: machine.location.x + 0.5,
                    y: machine.location.y + 1,
                    z: machine.location.z + 0.5
                };
                dimension.spawnItem(itemStack, dropLocation);
            }
        }

        // Run effects
        machine.runCommand('particle lv_te:ore_generator_generate ~~1.5~');
        machine.runCommand('playsound break.tuff @a ~~~');
    }
}
