import { system, world, BlockInventoryComponent, ItemStack } from '@minecraft/server';

export class Fred {
    static initialize() {
        // Periodically check machines
        system.runInterval(() => {
            Fred.runFred();
        }, 50); // Run every 2.5 seconds
    }

    static runFred() {
        const dimensions = ["overworld", "nether", "the_end"];

        // Iterate through each dimension
        for (const dimensionName of dimensions) {
            const dimension = world.getDimension(dimensionName);
            if (!dimension) continue;

            // Get all machines in the dimension
            const entities = dimension.getEntities().filter(entity => entity.typeId === "lv_te:fred");

            // Process each machine
            for (const machine of entities) {
                Fred.checkFuelState(machine);
                Fred.chargingLogic(machine);
            }
        }
    }

    static checkFuelState(machine) {
        //Skin ID will throw undefined once its in charging mode
        const skinId = machine.getComponent("minecraft:skin_id")?.value;
        const variant = machine.getComponent("minecraft:variant")?.value;
        
        if (skinId == 2) return; // Skin ID is 1, no need to check further

        // Check Fred's inventory for "lv_te:gasoline"
        const inventory = machine.getComponent("minecraft:inventory");
        if (!inventory) return;

        const container = inventory.container;
        const size = 27; // Get the inventory size

        for (let slot = 0; slot < size; slot++) {
            const item = container.getItem(slot);
            if (item && item.typeId === "lv_te:gasoline") {
                // Gasoline found, no need to trigger the event
                return;
            }
        }


        if (variant == 1) return;

        // Trigger the "move_to_station" event if no gasoline is found

        machine.triggerEvent("move_to_station");

    }

    static chargingLogic(machine) {

        const position = machine.location;
        const dimension = machine.dimension;

        const variant = machine.getComponent("minecraft:variant").value;
        if (variant != 1) return; // Variant is 1, no need to check further

        // Search for nearby "lv_te:charging_station" entities within 1.5 blocks
        const nearbyStations = dimension.getEntities({
            location: position,
            maxDistance: 1.5,
            type: "lv_te:charging_station"
        });

        if (nearbyStations.length === 0) return; // No charging station nearby

        const chargingStation = nearbyStations[0]; // Assume one charging station is sufficient

        // Get the inventories of Fred and the charging station
        const fredInventory = machine.getComponent("minecraft:inventory")?.container;
        const stationInventory = chargingStation.getComponent("minecraft:inventory")?.container;

        if (!fredInventory || !stationInventory) return;

        // Transfer gasoline items from the charging station to Fred
        for (let i = 0; i < stationInventory.size; i++) {
            const stationItem = stationInventory.getItem(i);

            if (stationItem && stationItem.typeId === "lv_te:gasoline") {
                // Check if Fred's inventory can accommodate the gasoline
                const addedToFred = fredInventory.addItem(new ItemStack("lv_te:gasoline", stationItem.amount));

                stationInventory.setItem(i, undefined);

                break; // Exit after processing one stack
            }
        }


    }
}
