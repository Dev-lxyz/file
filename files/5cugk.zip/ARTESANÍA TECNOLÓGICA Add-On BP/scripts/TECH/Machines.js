import { system, world, BlockInventoryComponent, MolangVariableMap, ItemStack } from '@minecraft/server';
import * as MC from './MachinesConstants.js';
import { MachineClass } from './MachineClass.js';
import { MachinePipes } from './MachinePipes.js';
import { inputOffset, outputOffset } from './MachinesConstants.js';

export class Machines {

    static checkIfMachineInRange() {
        const entitiesInRangeCache = new Set(); // Track currently in-range entities

        system.runInterval(() => {
            const range = 5;

            // Iterate over all players in the world
            world.getPlayers().forEach((player) => {
                const playerLocation = player.location;
                const dimension = player.dimension;

                // Find entities with the family 'lv_te:charge_bar' within range
                const entitiesInRange = dimension.getEntities({
                    location: playerLocation,
                    radius: range,
                    maxDistance: range,
                    families: ["lv_te:charge_bar"],
                });

                // Convert current in-range entities to a set for comparison
                const currentInRange = new Set(entitiesInRange.map((entity) => entity.id));

                // Handle newly entered entities
                entitiesInRange.forEach((entity) => {
                    // Spawn particle for entities currently in range
                    try {
                        // Set Molang variables to orient the particles in the player's view direction
                        const molangVariables = new MolangVariableMap();
                        const charge = entity.getProperty('lv_te:charge');

                        // Map charge (0–100) to particleIndex (0–5)
                        let particleIndex = Math.floor((charge / 100) * 5);

                        // Ensure that if charge is 1, particleIndex is at least 1
                        if (charge > 0 && particleIndex === 0) {
                            particleIndex = 1;
                        }
                        molangVariables.setFloat("index", particleIndex);
                        if(entity.typeId === "lv_te:auto_treecutter") {
                            if(entity.getProperty('lv_te:sapling') != 0) {
                                entity.dimension.spawnParticle("lv_te:charge_bar", { x: entity.location.x, y: entity.location.y + 2.5, z: entity.location.z }, molangVariables);
                            }
                        } else {
                            entity.dimension.spawnParticle("lv_te:charge_bar", { x: entity.location.x, y: entity.location.y + 1.5, z: entity.location.z }, molangVariables);
                        }

                    } catch (error) {
                        console.error(`Error spawning particle for entity ${entity.id}:`, error);
                    }
                });

                // Update the global cache with current entities in range
                entitiesInRangeCache.clear();
                currentInRange.forEach((entityId) => entitiesInRangeCache.add(entityId));
            });
        }, 10); // Run every 10 ticks (0.5 seconds)
    }

    static spawnFuelDummy(entity) {

        // Spawn "lv_te:charge_dummy" entity 1 block above if not already present
        const spawnPosition = {
            x: entity.location.x,
            y: entity.location.y + 1,
            z: entity.location.z
        };

        // Check for existing "lv_te:charge_dummy" entities at the position
        const entitiesAtPosition = entity.dimension.getEntities({
            type: "lv_te:charge_dummy",
            location: spawnPosition,
            maxDistance: 0.5
        });

        if (entitiesAtPosition.length === 0) {
            entity.runCommand(`summon lv_te:charge_dummy ${spawnPosition.x} ${spawnPosition.y} ${spawnPosition.z} 0 0 fuel_needed`);
        }

    }

    static runSiphoningProcess() {
        system.runInterval(() => {
            const dimensions = ["overworld", "nether", "the_end"];

            // Iterate through each dimension
            for (const dimensionName of dimensions) {
                const dimension = world.getDimension(dimensionName);
                if (!dimension) continue;

                // Get all machines in the dimension
                const entities = dimension.getEntities().filter(entity => MC.machines.includes(entity.typeId));

                // Process each machine
                for (const machine of entities) {
                    MachineClass.processMachine(machine, dimension);
                }
            }
        }, 5); // Run every second (20 ticks)
    }


    static changeAdvancedPipeColor(block, colorCode) {
        system.run(() => {
            let newBlockPermutation = block.permutation;
            newBlockPermutation = newBlockPermutation.withState("lv_te:color", colorCode);
            block.setPermutation(newBlockPermutation);
        })
    }

    static run() {

        const interactionCooldown = new Set();

        world.beforeEvents.itemUseOn.subscribe((eventData) => {
            const { source, block, itemStack } = eventData;
            if (block.typeId === "lv_te:advanced_pipe") {
                // Check if the player is on cooldown
                if (interactionCooldown.has(source.id)) return;

                // Add the player to the cooldown set
                interactionCooldown.add(source.id);

                // Remove the player from the cooldown set after 5 ticks (0.25 seconds)
                system.runTimeout(() => {
                    interactionCooldown.delete(source.id);
                }, 5);
                switch (itemStack.typeId) {
                    case "minecraft:white_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_white ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 0);
                        break;
                    case "minecraft:black_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_black ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 1);
                        break;
                    case "minecraft:pink_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_pink ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 2);
                        break;
                    case "minecraft:green_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_green ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 3);
                        break;
                    case "minecraft:blue_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_blue ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 4);
                        break;
                    case "minecraft:red_dye":
                        source.runCommandAsync(`playsound brush.generic @a ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        source.runCommandAsync(`particle lv_te:pipe_color_red ${block.location.x} ${block.location.y + 0.45} ${block.location.z}`);
                        this.changeAdvancedPipeColor(block, 5);
                        break;
                    default:
                        return;
                }
            } else if (block.typeId === "lv_te:copper_pipe") {
                const loc = {
                    x: block.location.x + 0.5,
                    y: block.location.y + 0.5,
                    z: block.location.z + 0.5,
                };
                const entities = block.dimension.getEntities({
                    location: loc,
                    maxDistance: 0.5,
                    families: ["lv.te.pipe"],
                    closest: true,
                });

                if (!entities.length) return; // No entities at this block location

                // Check if the player is on cooldown
                if (interactionCooldown.has(source.id)) return;

                // Add the player to the cooldown set
                interactionCooldown.add(source.id);

                // Remove the player from the cooldown set after 5 ticks (0.25 seconds)
                system.runTimeout(() => {
                    interactionCooldown.delete(source.id);
                }, 5);

                const heldItem = itemStack;
                const blockPermutation = block.permutation;

                const isWaxed = entities[0].getProperty("lv_te:waxed") || false;
                const oxidizationLevel = blockPermutation.getState("lv_te:oxidization") || 0;

                // Check for waxing interaction
                if (
                    heldItem?.typeId === "minecraft:honeycomb" &&
                    !isWaxed
                ) {
                    entities.forEach((entity) => {
                        entity.runCommandAsync("event entity @s lv_te:wax_machine");
                    });
                }

                // Check for removing wax
                const axeTypes = [
                    "minecraft:diamond_axe",
                    "minecraft:golden_axe",
                    "minecraft:iron_axe",
                    "minecraft:stone_axe",
                    "minecraft:wooden_axe",
                    "minecraft:netherite_axe",
                    "lv_te:steel_axe",
                    "lv_te:tech_axe",
                    "lv_te:titanium_axe",
                ];

                if (
                    axeTypes.includes(heldItem?.typeId) &&
                    isWaxed
                ) {
                    entities.forEach((entity) => {
                        entity.runCommandAsync("event entity @s lv_te:remove_wax");
                    });
                }

                // Check for oxidization removal
                if (
                    axeTypes.includes(heldItem?.typeId) &&
                    oxidizationLevel > 0
                ) {
                    entities.forEach((entity) => {
                        entity.runCommandAsync("event entity @s lv_te:oxidization_remove");
                    });
                }
            }
        });



        MachineClass.checkForChestAndHolograms();
        world.afterEvents.entitySpawn.subscribe((e) => {
            const { entity, cause } = e;
            if (cause === 'Spawned') {
                if (entity.typeId == "lv_te:sara") {
                    entity.runCommandAsync('particle lv_te:sara_spawn ~~0.1~');
                }
                if (!MC.machines.includes(entity.typeId)) return;

                const inputPosition = MachineClass.getInputLocation(entity);
                const outputPosition = MachineClass.getOutputLocation(entity);

                if (inputPosition) {
                    MachineClass.spawnContainerHologram(entity, inputPosition, "lv_te:input_look");
                }

                if (outputPosition) {
                    MachineClass.spawnContainerHologram(entity, outputPosition, "lv_te:output_look");
                }

                const rotation = MachineClass.normalizeRotation(entity.getRotation().y);

                if (entity.typeId === 'lv_te:cooking_pot') {
                    MachineClass.machinesBlock(entity, rotation, "lv_te:invis_cooking_pot");
                } 
                else {
                    MachineClass.machinesBlock(entity, rotation);
                }
            }
        });

        Machines.runSiphoningProcess();
        Machines.checkIfMachineInRange();
        //MachinePipes.pipeSiphonLogic();


        // Script Events
        system.afterEvents.scriptEventReceive.subscribe((e) => {
            try {
                const { id, sourceEntity, sourceBlock } = e;
                if (!sourceEntity) return;

                if (sourceBlock) {
                    let newBlockPermutation = sourceBlock.permutation;
                }

                switch (id) {
                    case 'lv.te:machines.cracking':
                        const currentCrackState = sourceEntity.getProperty('lv.te:cracking');
                        sourceEntity.setProperty('lv.te:cracking', currentCrackState + 1);

                        if (currentCrackState + 1 == 3) {
                            sourceEntity.runCommand('playsound break.tuff @a ~~~');
                            sourceEntity.runCommand('particle lv_te:break_machine ~~0.5~');
                            const rawRotation = sourceEntity.getRotation().y;
                            const rotation = MachineClass.normalizeRotation(rawRotation); // Normalize rotation to nearest 0, 90, 180, or 270   

                            MachineClass.removeBlocks(sourceEntity, rotation);
                            MachineClass.despawnHolograms(sourceEntity); // Despawn holograms
                            MachineClass.removeTimerForEntity(sourceEntity.id);
                            sourceEntity.runCommand('stopsound @a[r=3] lv_te.machine_static_0');
                            const sourceLoc = sourceEntity.location;
                            try {
                                // Drop items and remove entity
                                const inventory = sourceEntity.getComponent("minecraft:inventory")?.container;
                                if (inventory) {

                                    // Drop all items in the entity inventory
                                    for (let i = 0; i < inventory.size; i++) {
                                        const itemStack = inventory.getItem(i);
                                        if (itemStack) {
                                            sourceEntity.dimension.spawnItem(itemStack, sourceLoc);
                                            inventory.setItem(i, null);
                                        }
                                    }
                                }
                                const sourceName = sourceEntity.typeId;

                                if (sourceName != "lv_te:charging_station") {
                                    sourceEntity.dimension.spawnItem(new ItemStack(sourceName, 1), sourceLoc);
                                }
                                sourceEntity.triggerEvent('lv_te:remove_machine');

                            } catch (error) {
                                console.warn(error);
                            }



                        }

                        MachineClass.resetCracking(sourceEntity); // Reset cracking timer
                        break;
                    case 'lv.te:tech_mech.cracking':
                        const mechCrackState = sourceEntity.getProperty('lv.te:cracking');
                        sourceEntity.setProperty('lv.te:cracking', mechCrackState + 1);

                        if (mechCrackState + 1 == 3) {
                            sourceEntity.runCommand('playsound break.tuff @a ~~~');
                            const rawRotation = sourceEntity.getRotation().y;

                            const sourceLoc = sourceEntity.location;
                            try {
                                // Drop items and remove entity
                                const inventory = sourceEntity.getComponent("minecraft:inventory")?.container;
                                if (inventory) {

                                    // Drop all items in the entity inventory
                                    for (let i = 0; i < inventory.size; i++) {
                                        const itemStack = inventory.getItem(i);
                                        if (itemStack) {
                                            sourceEntity.dimension.spawnItem(itemStack, sourceLoc);
                                            inventory.setItem(i, null);
                                        }
                                    }
                                }
                                const sourceName = sourceEntity.typeId + "_spawn_egg";
                                sourceEntity.dimension.spawnItem(new ItemStack(sourceName, 1), sourceLoc);

                                sourceEntity.triggerEvent('lv_te:remove_machine');

                            } catch (error) {
                                //console.warn(error);
                            }
                        }

                        MachineClass.resetCracking(sourceEntity); // Reset cracking timer
                        break;
                    case 'lv.te:machines.fuel.coal':
                        const currentCharge = sourceEntity.getProperty('lv_te:charge');
                        const newCharge = Math.min(currentCharge + 10, 100);
                        sourceEntity.setProperty('lv_te:charge', newCharge);
                        break;
                    case 'lv_te:break.pipe':
                        sourceEntity.runCommand('fill ~~~ ~~~ air destroy');
                        sourceEntity.triggerEvent('lv_te:despawn');
                        break;
                    case 'lv_te:pipe.oxidization.changed':
                        system.runTimeout(() => {
                            const pipeBlock = sourceEntity.dimension.getBlock(sourceEntity.location); // The block that triggered the event
                            const oxidizationLevel = sourceEntity.getProperty('lv_te:oxidization');

                            let newBlockPermutation = pipeBlock.permutation;
                            newBlockPermutation = newBlockPermutation.withState("lv_te:oxidization", oxidizationLevel);
                            pipeBlock.setPermutation(newBlockPermutation);
                        }, 5);
                        break;
                    case 'lv.te:woodcutter_menu.next_recipe':
                        if (sourceEntity.getProperty(`lv_te:recipe`) + 1 > 6) {
                            sourceEntity.setProperty(`lv_te:recipe`, 0);
                            break;
                        }
                        sourceEntity.setProperty(`lv_te:recipe`, sourceEntity.getProperty(`lv_te:recipe`) + 1);
                        break;
                    case 'lv.te:woodcutter_menu.prev_recipe':
                        if (sourceEntity.getProperty(`lv_te:recipe`) - 1 < 0) {
                            sourceEntity.setProperty(`lv_te:recipe`, 6);
                            break;
                        }
                        sourceEntity.setProperty(`lv_te:recipe`, sourceEntity.getProperty(`lv_te:recipe`) - 1);
                        break;
                    case 'lv.te:tech_mech.attack':
                        {
                            const MECH = sourceEntity; // The entity executing the attack
                            const ATTACK_RADIUS = 3; // Range of the attack
                            const KNOCKBACK_STRENGTH = 2.5; // Knockback intensity
                            const DAMAGE_AMOUNT = 5; // Damage dealt to each affected entity
                            const MECH_ROTATION = MECH.getRotation();
                            // Get the mech's rotation (direction it's facing)
                            const yaw = (MECH_ROTATION.y * Math.PI) / 180; // Convert yaw to radians

                            // Calculate the forward vector
                            const forwardX = Math.sin(-yaw);
                            const forwardZ = Math.cos(-yaw);
                            // Calculate the offset location (2 blocks in front of the MECH)
                            const offsetLocation = {
                                x: MECH.location.x + forwardX * 2,
                                y: MECH.location.y,
                                z: MECH.location.z + forwardZ * 2,
                            };

                            // Find entities in the attack range
                            const entities = MECH.dimension.getEntities({
                                location: offsetLocation,
                                maxDistance: ATTACK_RADIUS,
                                families: ['mob'], // Define the types of entities affected
                                excludeFamilies: ['player', 'lv_te.tech_mech_suit'], // Exclude self and other mechs
                            });

                            // Process each entity in range
                            for (const entity of entities) {

                                // Calculate direction to the entity
                                const directionX = entity.location.x - MECH.location.x;
                                const directionZ = entity.location.z - MECH.location.z;
                                const dotProduct = directionX * forwardX + directionZ * forwardZ;

                                // Check if the entity is in front of the mech
                                if (dotProduct > 0) {
                                    // Knock back the entity
                                    const knockbackX = directionX * KNOCKBACK_STRENGTH;
                                    const knockbackZ = directionZ * KNOCKBACK_STRENGTH;

                                    // Deal damage to the entity
                                    entity.applyDamage(DAMAGE_AMOUNT, {
                                        cause: "entityAttack",
                                        damagingEntity: MECH,
                                    });
                                    entity.runCommand(`particle lv_te:boosting_pad ${entity.location.x} ${entity.location.y} ${entity.location.z}`);
                                    entity.applyKnockback(knockbackX, knockbackZ, KNOCKBACK_STRENGTH, 1);
                                }
                            }
                        }
                        break;
                    case "lv.te:advanced_pipe.color.0":
                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 0);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case "lv.te:advanced_pipe.color.1":
                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 1);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case "lv.te:advanced_pipe.color.2":
                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 2);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case "lv.te:advanced_pipe.color.3":
                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 3);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case "lv.te:advanced_pipe.color.4":
                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 4);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case "lv.te:advanced_pipe.color.5":
                        console.log("test", sourceBlock.typeId);

                        newBlockPermutation = sourceBlock.permutation;
                        newBlockPermutation = newBlockPermutation.withState("lv_te:color", 5);
                        sourceBlock.setPermutation(newBlockPermutation);
                        break;
                    case 'lv.te:fred.charge_machine': {
                        try {
                            // Define the range for searching entities
                            const searchRadius = 3; // Adjust this value as needed

                            // Get all entities within the radius of the sourceEntity
                            const nearbyEntities = sourceEntity.dimension.getEntities({
                                location: sourceEntity.location,
                                maxDistance: searchRadius,
                                families: ["lv_te:charge_bar"]
                            });
                            nearbyEntities.forEach(entity => {
                                // Get the current charge of the entity
                                let currentCharge = entity.getProperty("lv_te:charge");

                                while (currentCharge < 100) {
                                    // Search for a gasoline item in the inventory
                                    let gasolineSlot = null;
                                    const inventory = sourceEntity.getComponent("minecraft:inventory").container;

                                    for (let i = 0; i < inventory.size; i++) {
                                        const item = inventory.getItem(i);
                                        if (item && item.typeId === "lv_te:gasoline") {
                                            gasolineSlot = { item, index: i };
                                            break;
                                        }
                                    }

                                    if (!gasolineSlot) {
                                        break; // Exit the loop if no gasoline is found
                                    }

                                    // Calculate new charge and reduce gasoline amount
                                    currentCharge = Math.min(currentCharge + 10, 100);
                                    const remainingGasoline = gasolineSlot.item.amount - 1;

                                    // Create a new ItemStack with the updated amount
                                    if (remainingGasoline > 0) {
                                        const updatedItemStack = new ItemStack(gasolineSlot.item.typeId, remainingGasoline);
                                        inventory.setItem(gasolineSlot.index, updatedItemStack);
                                    } else {
                                        // Remove the item if the amount reaches 0
                                        inventory.setItem(gasolineSlot.index, undefined);
                                    }

                                    entity.setProperty("lv_te:charge", currentCharge);
                                }

                                // Get and despawn all charge dummies near the entity
                                const chargeDummies = entity.dimension.getEntities({
                                    location: { x: entity.location.x, y: entity.location.y + 1, z: entity.location.z },
                                    maxDistance: 0.6,
                                    families: ["fuel_needed"]
                                });

                                chargeDummies.forEach(dummy => {
                                    dummy.triggerEvent("lv_te:despawn");
                                });
                            });


                        } catch (error) {
                            // Log an error if something goes wrong
                        }
                        break;
                    }
                    case 'lv.te:machines.spawnFuelDummy': {
                        Machines.spawnFuelDummy(sourceEntity);
                        break;
                    }
                    case 'lv.te:machines.break.fred': {
                        const uniqueTags = sourceEntity.getTags(); // Get all tags of the entity

                        // Identify the unique tag shared by related entities
                        const sharedTag = uniqueTags.find(tag => tag.startsWith("pair_"));

                        if (sharedTag) {
                            // Get all entities in the dimension
                            const allEntities = sourceEntity.dimension.getEntities();
                            sourceEntity.runCommandAsync('title @p actionbar §8[§6!§8]§e F.R.E.D. and Charging Station were removed!')
                            // Filter entities that share the same tag
                            allEntities.forEach(closeEntity => {
                                if (closeEntity.hasTag(sharedTag)) {

                                    // Trigger the event "lv_te:instant_cracking"
                                    closeEntity.triggerEvent("lv_te:instant_cracking");
                                }
                            });
                        }
                        break;
                    }
                }
            } catch (error) {
                console.warn(error);

            }
        });
    }
}
