import { BlockPermutation } from '@minecraft/server';

const CustomLight = {
    onTick(event) {

        const { block, dimension } = event;
        if (!block || !dimension) {
            return;
        }
        const playerCheckLocation = {x: block.location.x, y: block.location.y - 1, z: block.location.z}
        const players = dimension.getEntities({
            location: playerCheckLocation,
            maxDistance: 1.4,
            type: 'minecraft:player'
        });

        if (players.length === 0) {
            block.setPermutation(BlockPermutation.resolve('minecraft:air'));
        }
    }
};

export default CustomLight;
