import { Player } from '@minecraft/server';

const BoostingPad = {
    onStepOn(event) {
        const { entity, block, dimension } = event;



        // Get the player's rotation (yaw and pitch)
        const rotation = entity.getRotation(); // Assuming getRotation gives yaw and pitch in degrees


        const yaw = (rotation.y * Math.PI) / 180; // Convert yaw to radians
        // Calculate the direction vector for knockback
        const knockbackX = -Math.sin(yaw); // Forward direction on X-axis
        const knockbackZ = Math.cos(yaw);  // Forward direction on Z-axis
        const upwardStrength = 1;       // Slight upward boost
        const horizontalStrength = 2.5;  // Boost strength for forward direction#

        entity.runCommand(`playsound mob.enderdragon.flap @a ${block.location.x} ${block.location.y} ${block.location.z} 0.7 1.2 0.001`);
        entity.runCommand(`particle lv_te:boosting_pad ${block.location.x} ${block.location.y} ${block.location.z}`);
        // Apply knockback to the player
        entity.applyKnockback(knockbackX, knockbackZ, horizontalStrength, upwardStrength);
        
    },
};

export default BoostingPad;
