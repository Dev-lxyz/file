import { BlockPermutation, Player, EquipmentSlot, GameMode } from "@minecraft/server";

const TechGauntlet = {
    onMineBlock(event) {
        const { block, source } = event; // Destructure the block and source from the event.

        // Ensure the source is a player.
        if (!(source instanceof Player)) return;

        // Define blocks that should not be broken.
        const unbreakableBlocks = ["minecraft:bedrock", "minecraft:obsidian", "minecraft:water", "minecraft:lava"];

        // Get the coordinates of the block.
        const { x, y, z } = block.location;

        // Iterate through a 3x3x3 area around the block.
        for (let dx = -1; dx <= 1; dx++) {
            for (let dy = -1; dy <= 1; dy++) {
                for (let dz = -1; dz <= 1; dz++) {
                    try {

                        const targetBlock = block.dimension.getBlock({
                            x: x + dx,
                            y: y + dy,
                            z: z + dz,
                        });

                        // Check if the block is not in the unbreakable list.
                        if (targetBlock && !unbreakableBlocks.includes(targetBlock.type.id)) {
                            // Simulate breaking the block.
                            source.runCommandAsync(
                                `setblock ${targetBlock.location.x} ${targetBlock.location.y} ${targetBlock.location.z} air destroy`
                            );
                        }

                    } catch (error) {

                    }
                }
            }
        }
    },
};

export default TechGauntlet;
