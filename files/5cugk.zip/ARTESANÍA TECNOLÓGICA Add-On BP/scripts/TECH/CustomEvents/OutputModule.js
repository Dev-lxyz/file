import * as MC from '../MachinesConstants.js';

const OutputModule = {
    onTick(event) {

        const { block, dimension } = event;
        if (!block || !dimension) {
            return;
        }
        const directions = {
            north: { method: () => block.north() },
            south: { method: () => block.south() },
            east: { method: () => block.east() },
            west: { method: () => block.west() },
            up: { method: () => block.above() },
            down: { method: () => block.below() }
        };

        const oppositeDirections = {
            down: { x: 0, y: 0.5, z: 0 }, // down -> up
            up: { x: 0, y: -0.5, z: 0 }, // up -> down
            north: { x: 0, y: 0, z: 0.5 }, // north -> south
            south: { x: 0, y: 0, z: -0.5 }, // south -> north
            west: { x: 0.5, y: 0, z: 0 }, // west -> east
            east: { x: -0.5, y: 0, z: 0 }, // east -> west
        };

        let facingDirection = block.permutation.getState("minecraft:facing_direction");
        const direction = directions[facingDirection];
        let pipeBlock = direction.method();

        if (pipeBlock && MC.pipeBlocks.includes(pipeBlock.typeId)) {
            const pipeEntity = dimension.getEntities({
                location: { x: pipeBlock.location.x + 0.5, y: pipeBlock.location.y + 0.5, z: pipeBlock.location.z + 0.5 },
                maxDistance: 0.5,
                type: 'lv_te:pipe_dummy',
            });

            if (pipeEntity.length > 0) {
                // Example action: Remove one item and drop it at block location
                const entity = pipeEntity[0];
                const inventory = entity.getComponent('minecraft:inventory');
                if (inventory && inventory.container.size > 0) {
                    const item = inventory.container.getItem(0);
                    if (item) {
                        inventory.container.setItem(0, null); // Remove item                        
             
                        // Calculate velocity based on opposite direction
                        const velocity = oppositeDirections[facingDirection] || { x: 0, y: 0, z: 0 };

                        // Spawn the item with velocity
                        const spawnedItem = dimension.spawnItem(item, {
                            x: block.location.x + 0.5,
                            y: block.location.y + 0.2,
                            z: block.location.z + 0.5
                        });

                        spawnedItem.clearVelocity();
                        spawnedItem.applyImpulse(velocity);
                        dimension.spawnParticle('lv_te:output_module', { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 });
                        dimension.playSound("random.pop", { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 });
                    }
                }
            }
        }
    }
};

export default OutputModule;
