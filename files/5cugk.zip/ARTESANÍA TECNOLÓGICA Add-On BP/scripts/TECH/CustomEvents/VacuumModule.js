import * as MC from '../MachinesConstants.js';

const VacuumModule = {
    onTick(event) {

        const { block, dimension } = event;
        if (!block || !dimension) {
            return;
        }

        const itemEntities = dimension.getEntities({
            location: { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 },
            maxDistance: 1.2,
            type: 'minecraft:item',
        });

        if (itemEntities.length > 0) {

            const directions = {
                north: { method: () => block.north() },
                south: { method: () => block.south() },
                east: { method: () => block.east() },
                west: { method: () => block.west() },
                up: { method: () => block.above() },
                down: { method: () => block.below() }
            };

            let facingDirection = block.permutation.getState("minecraft:facing_direction");
            const direction = directions[facingDirection];
            let pipeBlock = direction.method();
            if (pipeBlock && MC.pipeBlocks.includes(pipeBlock.typeId)) {
                // Check for pipe entities at the pipe block's location
                const pipeEntity = dimension.getEntities({
                    location: {
                        x: pipeBlock.location.x + 0.5,
                        y: pipeBlock.location.y + 0.5,
                        z: pipeBlock.location.z + 0.5,
                    },
                    maxDistance: 0.5,
                    type: 'lv_te:pipe_dummy',
                });
                if (pipeEntity.length > 0) {
                    const entity = pipeEntity[0];
                    const inventory = entity.getComponent('minecraft:inventory');

                    if (inventory) {
                        const container = inventory.container;

                        // Loop through item entities and attempt to insert into the inventory
                        for (const itemEntity of itemEntities) {
                            const itemStack = itemEntity.getComponent('minecraft:item').itemStack;

                            // Check if the inventory has space for this item
                            let addedToInventory = false;
                            for (let i = 0; i < container.size; i++) {
                                const slot = container.getItem(i);

                                if (!slot) {
                                    // Empty slot found, add the item
                                    container.setItem(i, itemStack);
                                    addedToInventory = true;
                                    break;
                                } else if (slot.typeId === itemStack.typeId && slot.amount + itemStack.amount <= slot.maxAmount) {
                                    // Mergeable stack found, add to it
                                    slot.amount += itemStack.amount;
                                    container.setItem(i, slot);
                                    addedToInventory = true;
                                    break;
                                }
                            }

                            // If added to inventory, remove the item from the ground
                            if (addedToInventory) {
                                itemEntity.kill();
                                dimension.spawnParticle('lv_te:vacuum_module', { x: block.location.x + 0.5, y: block.location.y + 0.4, z: block.location.z + 0.5 });
                                dimension.playSound("random.pop2", { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 });
                            }
                        }
                    }
                }
            }
        }
    },
};

export default VacuumModule;
