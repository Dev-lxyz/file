import { ItemStack, Player } from "@minecraft/server";

const Woodcutter = {
    onPlayerInteract(event) {
        const { player, block, dimension } = event;

        if (!block || !player) return;

        const inventory = player.getComponent("minecraft:inventory")?.container;
        const selectedSlot = player.selectedSlotIndex;
        if (!inventory) return;

        const itemStack = inventory.getItem(selectedSlot);

        const plankRecipes = {
            "minecraft:oak_planks": [
                "oak_stairs",
                "oak_slab",
                "fence_gate",
                "oak_fence",
                "oak_sign",
                "oak_boat",
                "wooden_door",
            ],
            "minecraft:spruce_planks": [
                "spruce_stairs",
                "spruce_slab",
                "spruce_fence_gate",
                "spruce_fence",
                "spruce_sign",
                "spruce_boat",
                "spruce_door",
            ],
            "minecraft:birch_planks": [
                "birch_stairs",
                "birch_slab",
                "birch_fence_gate",
                "birch_fence",
                "birch_sign",
                "birch_boat",
                "birch_door",
            ],
            "minecraft:jungle_planks": [
                "jungle_stairs",
                "jungle_slab",
                "jungle_fence_gate",
                "jungle_fence",
                "jungle_sign",
                "jungle_boat",
                "jungle_door",
            ],
            "minecraft:acacia_planks": [
                "acacia_stairs",
                "acacia_slab",
                "acacia_fence_gate",
                "acacia_fence",
                "acacia_sign",
                "acacia_boat",
                "acacia_door",
            ],
            "minecraft:dark_oak_planks": [
                "dark_oak_stairs",
                "dark_oak_slab",
                "dark_oak_fence_gate",
                "dark_oak_fence",
                "dark_oak_sign",
                "dark_oak_boat",
                "dark_oak_door",
            ],
            "minecraft:mangrove_planks": [
                "mangrove_stairs",
                "mangrove_slab",
                "mangrove_fence_gate",
                "mangrove_fence",
                "mangrove_sign",
                "mangrove_boat",
                "mangrove_door",
            ],
            "minecraft:cherry_planks": [
                "cherry_stairs",
                "cherry_slab",
                "cherry_fence_gate",
                "cherry_fence",
                "cherry_sign",
                "cherry_boat",
                "cherry_door",
            ],
            "minecraft:bamboo_planks": [
                "bamboo_stairs",
                "bamboo_slab",
                "bamboo_fence_gate",
                "bamboo_fence",
                "bamboo_sign",
                "bamboo_raft",
                "bamboo_door",
            ],
            "minecraft:crimson_planks": [
                "crimson_stairs",
                "crimson_slab",
                "crimson_fence_gate",
                "crimson_fence",
                "crimson_sign",
                "crimson_boat",
                "crimson_door",
            ],
            "minecraft:warped_planks": [
                "warped_stairs",
                "warped_slab",
                "warped_fence_gate",
                "warped_fence",
                "warped_sign",
                "warped_boat",
                "warped_door",
            ],
            "minecraft:pale_oak_planks": [
                "pale_oak_stairs",
                "pale_oak_slab",
                "pale_oak_fence_gate",
                "pale_oak_fence",
                "pale_oak_sign",
                "pale_oak_boat",
                "pale_oak_door",
            ],
        };

        if (itemStack && plankRecipes[itemStack.typeId]) {
            const recipeOutcomes = plankRecipes[itemStack.typeId];
            const blockLocation = block.location;

            const entitiesAtLocation = dimension.getEntitiesAtBlockLocation(
                blockLocation,
            );
            const woodcutterMenuEntity = entitiesAtLocation.find((entity) =>
                entity.typeId === "lv_te:woodcutter_menu"
            );

            const targetEntity = woodcutterMenuEntity ??
                dimension.spawnEntity("lv_te:woodcutter_menu", blockLocation);
            if (!targetEntity) return;

            const recipeIndex = targetEntity.getProperty("lv_te:recipe");
            if (recipeIndex >= 0 && recipeIndex < recipeOutcomes.length) {
                const resultItem = recipeOutcomes[recipeIndex];
                targetEntity.dimension.spawnItem(
                    new ItemStack(resultItem),
                    targetEntity.location,
                );

                // Deduct one plank from inventory
                if (itemStack.amount - 1 <= 0) {
                    inventory.setItem(selectedSlot, undefined);
                } else {
                    itemStack.amount -= 1;
                    inventory.setItem(selectedSlot, itemStack);
                }
            }
        }
    },
};

export default Woodcutter;
