import { Player } from "@minecraft/server";

const ManualOreExtractor = {
    onPlayerInteract(event) {
        const { player, block, dimension } = event;

        // Ensure the event has a block and the player is interacting with a valid block
        if (!block || !player) return;

        // Get the item in the player's hand
        const inventory = player.getComponent("minecraft:inventory")?.container;
        const selectedSlot = player.selectedSlotIndex;
        const itemStack = inventory.getItem(selectedSlot);

        // Check if the item is sand, gravel, or dirt
        if (
            itemStack &&
            (itemStack.typeId === "minecraft:sand" ||
                itemStack.typeId === "minecraft:gravel" ||
                itemStack.typeId === "minecraft:dirt")
        ) {
            // Ensure the block is of the correct type
            if (block.typeId === "lv_te:manual_ore_extractor") {
                const blockState = block.permutation.getState("lv_te:fill");

                // Ensure the block has the correct state
                if (blockState !== undefined) {
                    let currentFill = parseInt(blockState);

                    // Increment the fill state
                    currentFill += 1;

                    if (currentFill >= 8) {
                        // Trigger loot table and reset fill state
                        dimension.runCommandAsync(
                            `loot spawn ${block.location.x} ${
                                block.location.y + 1
                            } ${block.location.z} loot "lv/te/manual_ore_extractor"`,
                        );
                        currentFill = 1; // Reset to 1
                    }

                    // Update the block state
                    block.setPermutation(
                        block.permutation.withState("lv_te:fill", currentFill),
                    );

                    // Decrease the item count by 1

                    // Deduct one plank from inventory
                    if (itemStack.amount - 1 <= 0) {
                        inventory.setItem(selectedSlot, undefined);
                    } else {
                        itemStack.amount -= 1;
                        inventory.setItem(selectedSlot, itemStack);
                    }
                }
            }
        }
    },
    onTick(event) {
        const { block, dimension } = event;

        // Ensure the event contains a valid block and dimension
        if (!block || !dimension) return;

        // Calculate the location 0.5 blocks above the block
        const particleLocation = {
            x: block.location.x + 0.5,
            y: block.location.y + 1.5,
            z: block.location.z + 0.5,
        };

        // Spawn the particle at the calculated location
        dimension.spawnParticle(
            "lv_te:tooltip_manual_ore_extractor",
            particleLocation,
        );
    },
};

export default ManualOreExtractor;
