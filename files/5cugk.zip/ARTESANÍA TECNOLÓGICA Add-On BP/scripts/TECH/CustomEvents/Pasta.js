import { system, world } from '@minecraft/server';

const Pasta = {
    onConsume(event) {
        // Ensure the event source is a player
        const player = event.source;
        if (player && player.typeId === 'minecraft:player') {
            // Add the underwater breathing effect to the player for 10 seconds (200 ticks)
            player.addEffect("regeneration", 200, { showParticles: false, amplifier: 0 });
        }
    },
};

export default Pasta;
