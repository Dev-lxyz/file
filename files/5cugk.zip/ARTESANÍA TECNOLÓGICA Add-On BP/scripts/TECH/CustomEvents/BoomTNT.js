import { Player } from '@minecraft/server';

const BoomTNT = {
    onPlayerInteract(event) {
        const { player, block, dimension } = event;

        //Get Item in Hand
        const itemStack = player.getComponent('minecraft:inventory')?.container.getItem(player.selectedSlotIndex);

        if (itemStack.typeId === 'minecraft:flint_and_steel' || itemStack.typeId === 'minecraft:fire_charge') {
            block.setType("minecraft:air");
            player.runCommandAsync(`summon lv_te:boom_tnt ${block.location.x} ${block.location.y} ${block.location.z}`);
            player.runCommandAsync(`playsound random.fuse @a ${block.location.x} ${block.location.y} ${block.location.z}`);
        }
    },
};

export default BoomTNT;
