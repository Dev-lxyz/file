import { world, BlockPermutation } from '@minecraft/server';
import * as MC from './MachinesConstants.js';

export class MachinePipes {

	static pipeEntityMap = new Map(); // Optional tracking

	static registerPipeEntity(location, entity) {
		const key = `${location.x},${location.y},${location.z}`;
		this.pipeEntityMap.set(key, entity);
	}
	static checkPlacedPipeSurroundings(block, dimension) {
		const blockLocation = block.location;

		const faceState = block.permutation.getState("minecraft:block_face");
		const face = typeof faceState === "number" ? this.faceIdToName(faceState) : faceState;

		const dirMap = this.getDirectionMap(face);

		const relevantOffsets = this.getSurroundingOffsets().filter(offset =>
			offset.dir === face || offset.dir === this.invertDirection(face)
		);

		const connectionStates = {
			north: false,
			south: false,
			east: false,
			west: false,
			up: false,
			down: false,
		};

		for (const offset of relevantOffsets) {
			const neighborLoc = {
				x: blockLocation.x + offset.x,
				y: blockLocation.y + offset.y,
				z: blockLocation.z + offset.z,
			};
			const neighbor = dimension.getBlock(neighborLoc);
			if (!neighbor) continue;
			const connects = MC.pipeBlocks.includes(neighbor.typeId)
				|| MC.validContainers.includes(neighbor.typeId)
				|| neighbor.typeId === "lv_te:output_module"
				|| neighbor.typeId === "lv_te:vacuum_module"
				|| dimension.getEntities({
					location: {
						x: neighborLoc.x + 0.5,
						y: neighborLoc.y + 0.5,
						z: neighborLoc.z + 0.5
					},
					maxDistance: 0.75
				}).some(e => MC.machines.includes(e.typeId));

			if (!connects) continue;



			const thisVisualKey = dirMap[offset.opp];
			connectionStates[thisVisualKey] = true;

			if (MC.pipeBlocks.includes(neighbor.typeId)) {
				const neighborFaceState = neighbor.permutation.getState("minecraft:block_face");
				const neighborFace = typeof neighborFaceState === "number" ? this.faceIdToName(neighborFaceState) : neighborFaceState;
				const neighborDirMap = this.getDirectionMap(neighborFace);

				const neighborVisualKey = neighborDirMap[offset.dir];
				let neighborPerm = neighbor.permutation.withState(`lv_te:${neighborVisualKey}`, true);
				neighbor.setPermutation(neighborPerm);
			}
			// INPUT CHECK: pipe is facing the neighbor (opposite of pipe face)
			if (offset.dir === this.invertDirection(face)) {
				const pipeDummy = dimension.getEntities({
					location: {
						x: blockLocation.x + 0.5,
						y: blockLocation.y + 0.5,
						z: blockLocation.z + 0.5
					},
					families: ["lv.te.pipe"]
				})[0];

				// Neighbor has inventory (block or entity)
				const neighborHasInventory =
					MC.validContainers.includes(neighbor.typeId) ||
					dimension.getEntities({
						location: {
							x: neighborLoc.x + 0.5,
							y: neighborLoc.y + 0.5,
							z: neighborLoc.z + 0.5
						},
						maxDistance: 0.75
					}).some(e => e.hasComponent("minecraft:inventory"));

				if (pipeDummy && neighborHasInventory && pipeDummy.getProperty("lv_te:input") !== undefined) {
					pipeDummy.setProperty("lv_te:input", true);
				}
			}

			// OUTPUT CHECK: pipe is pointing away from neighbor and it’s a valid container
			if (offset.dir === face) {
				const pipeDummy = dimension.getEntities({
					location: {
						x: blockLocation.x + 0.5,
						y: blockLocation.y + 0.5,
						z: blockLocation.z + 0.5
					},
					families: ["lv.te.pipe"]
				})[0];

				const neighborHasInventory =
					MC.validContainers.includes(neighbor.typeId) ||
					dimension.getEntities({
						location: {
							x: neighborLoc.x + 0.5,
							y: neighborLoc.y + 0.5,
							z: neighborLoc.z + 0.5
						},
						maxDistance: 0.75
					}).some(e => e.hasComponent("minecraft:inventory"));

				if (pipeDummy && neighborHasInventory && pipeDummy.getProperty("lv_te:output") !== undefined) {
					pipeDummy.setProperty("lv_te:output", true);
				}
			}


		}

		let newPerm = block.permutation;
		for (const key in connectionStates) {
			newPerm = newPerm.withState(`lv_te:${key}`, connectionStates[key]);
		}
		block.setPermutation(newPerm);
	}



	static checkIfPipeOutputsTo(brokenBlock, dimension) {

		for (const offset of this.getSurroundingOffsets()) {
			const pipeLoc = {
				x: brokenBlock.location.x + offset.x,
				y: brokenBlock.location.y + offset.y,
				z: brokenBlock.location.z + offset.z
			};

			const pipe = dimension.getBlock(pipeLoc);
			if (!pipe || !MC.pipeBlocks.includes(pipe.typeId)) continue;

			const pipeFaceState = pipe.permutation.getState("minecraft:block_face");
			const pipeFace = typeof pipeFaceState === "number"
				? this.faceIdToName(pipeFaceState)
				: pipeFaceState;

			const dirMap = this.getDirectionMap(pipeFace);
			const expectedOutputDir = dirMap[offset.dir]; // this pipe was facing this direction toward the broken block

			const pipeDummy = dimension.getEntities({
				location: {
					x: pipeLoc.x + 0.5,
					y: pipeLoc.y + 0.5,
					z: pipeLoc.z + 0.5
				},
				families: ["lv.te.pipe"]
			})[0];

			if (!pipeDummy) continue;

			const outputProperty = pipeDummy.getProperty("lv_te:output");
			if (outputProperty !== undefined) {
				pipeDummy.setProperty("lv_te:output", false);
			}
		}
	}

	static checkIfPipeInputsFrom(brokenBlock, dimension) {
		for (const offset of this.getSurroundingOffsets()) {
			const pipeLoc = {
				x: brokenBlock.location.x + offset.x,
				y: brokenBlock.location.y + offset.y,
				z: brokenBlock.location.z + offset.z
			};

			const pipe = dimension.getBlock(pipeLoc);
			if (!pipe || !MC.pipeBlocks.includes(pipe.typeId)) continue;

			const pipeFaceState = pipe.permutation.getState("minecraft:block_face");
			const pipeFace = typeof pipeFaceState === "number"
				? this.faceIdToName(pipeFaceState)
				: pipeFaceState;

			const dirMap = this.getDirectionMap(pipeFace);
			const expectedInputDir = dirMap[offset.opp]; // pipe was reading FROM broken block

			const pipeDummy = dimension.getEntities({
				location: {
					x: pipeLoc.x + 0.5,
					y: pipeLoc.y + 0.5,
					z: pipeLoc.z + 0.5
				},
				families: ["lv.te.pipe"]
			})[0];

			if (!pipeDummy) continue;

			const inputProperty = pipeDummy.getProperty("lv_te:input");
			if (inputProperty !== undefined) {
				pipeDummy.setProperty("lv_te:input", false);
			}
		}
	}

	static checkSurroundingPipesAfterPlacement(placedBlock, dimension) {
		for (const offset of this.getSurroundingOffsets()) {
			const pipeLoc = {
				x: placedBlock.location.x + offset.x,
				y: placedBlock.location.y + offset.y,
				z: placedBlock.location.z + offset.z
			};

			const pipeBlock = dimension.getBlock(pipeLoc);
			if (!pipeBlock || !MC.pipeBlocks.includes(pipeBlock.typeId)) continue;

			const faceState = pipeBlock.permutation.getState("minecraft:block_face");
			const face = typeof faceState === "number"
				? this.faceIdToName(faceState)
				: faceState;

			const dirMap = this.getDirectionMap(face);
			const offsetDir = offset.dir;            // Direction from pipe → placed block
			const oppositeDir = offset.opp;          // From placed block → pipe

			const localOutputDir = dirMap[oppositeDir];
			const localInputDir = dirMap[offsetDir];

			const pipeDummy = dimension.getEntities({
				location: {
					x: pipeLoc.x + 0.5,
					y: pipeLoc.y + 0.5,
					z: pipeLoc.z + 0.5
				},
				families: ["lv.te.pipe"]
			})[0];

			let newPerm = pipeBlock.permutation;

			// Pipe is facing the placed block → it's outputting
			if (offsetDir === face) {
				newPerm = newPerm.withState(`lv_te:north`, true);
				if (pipeDummy) {
					pipeDummy.setProperty("lv_te:input", true);
				}

			}

			// Pipe is facing away from the placed block → it's inputting
			if (oppositeDir === face) {
				newPerm = newPerm.withState(`lv_te:south`, true);
				pipeDummy.setProperty("lv_te:output", true);
			}


			pipeBlock.setPermutation(newPerm);
		}
	}


	static checkSurroundingPipesAfterRemoval(brokenBlock, dimension) {
		for (const offset of this.getSurroundingOffsets()) {
			const pipeLoc = {
				x: brokenBlock.location.x + offset.x,
				y: brokenBlock.location.y + offset.y,
				z: brokenBlock.location.z + offset.z
			};

			const pipeBlock = dimension.getBlock(pipeLoc);
			if (!pipeBlock || !MC.pipeBlocks.includes(pipeBlock.typeId)) continue;

			const faceState = pipeBlock.permutation.getState("minecraft:block_face");
			const face = typeof faceState === "number"
				? this.faceIdToName(faceState)
				: faceState;

			const dirMap = this.getDirectionMap(face);
			const offsetDir = offset.dir;             // Direction from pipe → broken block
			const oppositeDir = offset.opp;           // Direction from broken block → pipe

			const localOutputDir = dirMap[offsetDir]; // This is the face pointing toward the broken block
			const localInputDir = dirMap[offset.opp]; // This is the face from the broken block side

			// Check if pipe was facing the broken block (output or input side)
			const pipeDummy = dimension.getEntities({
				location: {
					x: pipeLoc.x + 0.5,
					y: pipeLoc.y + 0.5,
					z: pipeLoc.z + 0.5
				},
				families: ["lv.te.pipe"]
			})[0];

			let newPerm = pipeBlock.permutation;

			// OUTPUT check: pipe is facing *toward* the broken block
			if (pipeDummy?.getProperty("lv_te:output") && offsetDir === face) {
				pipeDummy.setProperty("lv_te:output", false);
				newPerm = newPerm.withState(`lv_te:north`, false);
			}

			// INPUT check: pipe is facing *away* from the broken block (i.e., input from that side)
			if (pipeDummy?.getProperty("lv_te:input") && offset.opp === face) {
				pipeDummy.setProperty("lv_te:input", false);
				newPerm = newPerm.withState(`lv_te:south`, false);
			}

			pipeBlock.setPermutation(newPerm);
		}
	}


	static checkIfPipeCanInput(block, dimension) {
		const faceState = block.permutation.getState("minecraft:block_face");
		const face = typeof faceState === "number" ? this.faceIdToName(faceState) : faceState;
		const offset = this.directionToOffset(face);

		const targetLoc = {
			x: block.location.x + offset.x,
			y: block.location.y + offset.y,
			z: block.location.z + offset.z
		};

		const targetBlock = dimension.getBlock(targetLoc);
		let isValid = MC.validContainers.includes(targetBlock?.typeId) || MC.machines.includes(targetBlock?.typeId);

		if (!isValid) {
			const entities = dimension.getEntities({
				location: {
					x: targetLoc.x + 0.5,
					y: targetLoc.y + 0.5,
					z: targetLoc.z + 0.5
				},
				maxDistance: 0.75
			});

			isValid = entities.some(e => e.hasComponent("minecraft:inventory"));
		}

		const pipeDummy = dimension.getEntities({
			location: {
				x: block.location.x + 0.5,
				y: block.location.y + 0.5,
				z: block.location.z + 0.5
			},
			families: ["lv.te.pipe"]
		})[0];

		const inputProperty = pipeDummy.getProperty("lv_te:input");
		if (inputProperty !== undefined) {
			pipeDummy.setProperty("lv_te:input", true);
		}
	}

	static checkIfPipeCanOutput(block, dimension) {
		const faceState = block.permutation.getState("minecraft:block_face");
		const face = typeof faceState === "number" ? this.faceIdToName(faceState) : faceState;
		const forwardOffset = this.directionToOffset(face);
		const backOffset = this.directionToOffsetFromString(this.invertDirection(face));

		const targetLoc = {
			x: block.location.x + backOffset.x,
			y: block.location.y + backOffset.y,
			z: block.location.z + backOffset.z
		};

		const targetBlock = dimension.getBlock(targetLoc);
		let isValid = MC.validContainers.includes(targetBlock?.typeId) || MC.machines.includes(targetBlock?.typeId);

		if (!isValid) {
			const entities = dimension.getEntities({
				location: {
					x: targetLoc.x + 0.5,
					y: targetLoc.y + 0.5,
					z: targetLoc.z + 0.5
				},
				maxDistance: 0.75
			});

			isValid = entities.some(e => e.hasComponent("minecraft:inventory"));
		}

		const pipeDummy = dimension.getEntities({
			location: {
				x: block.location.x + 0.5,
				y: block.location.y + 0.5,
				z: block.location.z + 0.5
			},
			families: ["lv.te.pipe"]
		})[0];

		const outputProperty = pipeDummy.getProperty("lv_te:output");
		if (outputProperty !== undefined) {
			pipeDummy.setProperty("lv_te:output", true);
		}
	}


	static checkModuleFacingDirectionPipe(block, direction, dimension, placed = false) {
		const offset = this.directionToOffsetFromString(direction);
		const neighborLoc = {
			x: block.location.x + offset.x,
			y: block.location.y + offset.y,
			z: block.location.z + offset.z
		};
		const neighbor = dimension.getBlock(neighborLoc);

		if (!neighbor || !MC.pipeBlocks.includes(neighbor.typeId)) return;

		const faceState = neighbor.permutation.getState("minecraft:block_face");
		const face = typeof faceState === "number" ? this.faceIdToName(faceState) : faceState;

		const dirMap = this.getDirectionMap(face);
		const localKey = dirMap[direction]; // Direction the pipe faces *toward* the module

		let newPerm = neighbor.permutation.withState(`lv_te:${localKey}`, placed);
		neighbor.setPermutation(newPerm);
	}




	static handlePipeBreak(block, dimension) {
		const blockLocation = block.location;

		for (const offset of this.getSurroundingOffsets()) {
			const neighborLoc = {
				x: blockLocation.x + offset.x,
				y: blockLocation.y + offset.y,
				z: blockLocation.z + offset.z
			};

			const neighbor = dimension.getBlock(neighborLoc);
			if (!neighbor || !MC.pipeBlocks.includes(neighbor.typeId)) continue;

			// Determine how to update the neighbor
			const neighborFaceState = neighbor.permutation.getState("minecraft:block_face");
			const neighborFace = typeof neighborFaceState === "number"
				? this.faceIdToName(neighborFaceState)
				: neighborFaceState;

			const neighborDirMap = this.getDirectionMap(neighborFace);

			const neighborVisualKey = neighborDirMap[offset.dir]; // this pipe was in this direction from neighbor

			// Remove connection
			let newPerm = neighbor.permutation.withState(`lv_te:${neighborVisualKey}`, false);
			neighbor.setPermutation(newPerm);

			// Optional: Fully recheck the remaining connections
			this.checkPlacedPipeSurroundings(neighbor, dimension);
		}
	}

	static invertDirection(dir) {
		const map = {
			north: "south",
			south: "north",
			east: "west",
			west: "east",
			up: "down",
			down: "up"
		};
		return map[dir];
	}

	static directionToOffsetFromString(dir) {
		return this.getSurroundingOffsets().find(o => o.dir === dir) ?? { x: 0, y: 0, z: 0 };
	}
	static getDirectionFromOffset(offset) {
		if (offset.x === 1) return "east";
		if (offset.x === -1) return "west";
		if (offset.y === 1) return "up";
		if (offset.y === -1) return "down";
		if (offset.z === 1) return "south";
		if (offset.z === -1) return "north";
		return "unknown";
	}

	static getSurroundingOffsets() {
		return [
			{ x: 0, y: 1, z: 0, dir: 'up', opp: 'down' },
			{ x: 0, y: -1, z: 0, dir: 'down', opp: 'up' },
			{ x: 0, y: 0, z: -1, dir: 'north', opp: 'south' },
			{ x: 0, y: 0, z: 1, dir: 'south', opp: 'north' },
			{ x: 1, y: 0, z: 0, dir: 'east', opp: 'west' },
			{ x: -1, y: 0, z: 0, dir: 'west', opp: 'east' },
		];
	}

	static directionToOffset(facing) {
		switch (facing) {
			case 0: return { x: 0, y: 0, z: -1, opp: "south" }; // north
			case 1: return { x: 0, y: 0, z: 1, opp: "north" }; // south
			case 2: return { x: -1, y: 0, z: 0, opp: "east" }; // west
			case 3: return { x: 1, y: 0, z: 0, opp: "west" }; // east
			case 4: return { x: 0, y: 1, z: 0, opp: "down" }; // up
			case 5: return { x: 0, y: -1, z: 0, opp: "up" }; // down
			default: return { x: 0, y: 0, z: 0, opp: "north" };
		}
	}

	static getDirectionMap(face) {
		const map = {
			north: { north: 'north', south: 'south', east: 'east', west: 'west', up: 'down', down: 'up' },
			south: { north: 'south', south: 'north', east: 'west', west: 'east', up: 'down', down: 'up' },
			east: { north: 'west', south: 'east', east: 'north', west: 'south', up: 'down', down: 'up' },
			west: { north: 'east', south: 'west', east: 'south', west: 'north', up: 'down', down: 'up' },
			up: { north: 'down', south: 'up', east: 'west', west: 'east', up: 'north', down: 'south' },
			down: { north: 'up', south: 'down', east: 'west', west: 'east', up: 'south', down: 'north' },
		};
		return map[face] ?? map['north'];
	}



}
