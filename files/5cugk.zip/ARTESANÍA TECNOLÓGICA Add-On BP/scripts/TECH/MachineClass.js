import { system, world, BlockPermutation, ItemStack } from '@minecraft/server';
import * as MC from './MachinesConstants.js';
import { Machines } from './Machines.js';
import { MachinePipes } from './MachinePipes.js';

/**
 * UTILITY FUNCTIONS FOR MACHINES
 */

export class MachineClass {
	static crackingTimers = new Map(); // Map to track timers for each entity

	static processMachine(machine, dimension) {
		try {
			const machineConfig = MC.machineConfigs[machine.typeId];
			if (!machineConfig) {
				//console.warn(`No configuration found for machine ${machine.typeId}`);
				return;
			}

			const inputInventory = MachineClass.getInputInventory(machine, dimension);
			const outputInventory = MachineClass.getOutputInventory(machine, dimension);

			if (!inputInventory || !outputInventory) {
				//console.warn(`Invalid inventories for machine ${machine.typeId}`);
				return;
			}

			// Check if machine has enough fuel (if required)
			if (machineConfig.fuelUsage > 0) {
				const hasFuel = MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage, true);
				if (!hasFuel) {
					//console.warn(`Machine ${machine.typeId} is out of fuel.`);
					return;
				}
			}

			const container = inputInventory.container;
			if (!container) return;

			const containerSize = container.size;
			for (let i = 0; i < containerSize; i++) {
				const siphonItem = container.getItem(i);
				if (!siphonItem) {
					continue;
				}

				// Check if item is in allowedInputs
				if (!machineConfig.allowedInputs.includes(siphonItem.typeId)) {
					// Clone the item stack and move it to the output inventory
					const transfered = container.transferItem(i, outputInventory.container);
					continue;
				}

				// Get the output configuration for this input item
				const outputConfig = machineConfig.outputItems[siphonItem.typeId];
				if (!outputConfig) continue;

				// Pass the inputType explicitly to siphonInputItem
				const success = MachineClass.siphonInputItem(
					inputInventory,
					{ ...outputConfig, inputType: siphonItem.typeId }, // Add inputType dynamically
					machine
				);

				if (success) {
					MachineClass.attemptUseFuel(machine, machineConfig.fuelUsage);
					break; // Process only one slot per tick
				}
			}
		} catch (error) {
			//console.error(`Error processing machine ${machine.typeId}:`, error);
		}
	}



	static getValidInputItem(inputInventory, allowedInputs) {
		const container = inputInventory.container;
		if (!container) return null;

		const containerSize = container.size;
		for (let i = 0; i < containerSize; i++) {
			const item = container.getItem(i);
			if (item && allowedInputs.includes(item.typeId)) {
				return item;
			}
		}
		return null;
	}


	static siphonInputItem(inputInventory, outputConfig, machine) {
		const { inputAmount, outputAmount, typeId: outputTypeId, inputType } = outputConfig;

		const container = inputInventory.container;
		if (!container) {
			return false;
		}

		let totalCollectedInput = 0;
		const slotsToAdjust = []; // Tracks slots that need adjustment (cleared or updated)

		const containerSize = container.size;


		// Gather the required input amount from the container
		for (let i = 0; i < containerSize; i++) {
			const item = container.getItem(i);


			// Check if item exists and matches the expected input type
			if (item && item.typeId === inputType) {


				// Calculate how many items can be taken from this stack
				const collectibleAmount = Math.min(inputAmount - totalCollectedInput, item.amount);
				totalCollectedInput += collectibleAmount;

				slotsToAdjust.push({ slot: i, remaining: item.amount - collectibleAmount });

				// Break out of the loop if we've collected enough input
				if (totalCollectedInput >= inputAmount) break;
			} else if (item) {
				//console.warn(`siphonInputItem: Item in slot ${i} (${item.typeId}) does not match expected input type`);
			}
		}

		// If not enough input was collected, return false
		if (totalCollectedInput < inputAmount) {

			return false;
		}


		// Check if there's enough space in the output inventory
		const outputItem = new ItemStack(outputTypeId, outputAmount);
		if (!MachineClass.canOutputItem(machine, outputItem)) {

			return false;
		}

		// Adjust the input inventory based on the collected input
		for (const { slot, remaining } of slotsToAdjust) {
			if (remaining <= 0) {
				container.setItem(slot, null); // Clear fully consumed slots
			} else {
				const updatedItem = container.getItem(slot).clone();
				updatedItem.amount = remaining;
				container.setItem(slot, updatedItem); // Update slot with remaining amount
			}
		}

		// Output the processed items to the machine's output inventory
		MachineClass.outputItem(machine, outputItem);

		return true;
	}



	/**
	 * Process the logic for a specific machine.
	 * @param {object} machine - The machine entity to process.
	 * @param {int} amount - The amount that should be used
	 * @param {boolean} checkOnly - If the attempt should work as a simple check and not actually use up any fuel - default is false
	 */
	static attemptUseFuel(machine, amount, checkOnly = false) {
		try {
			const currentCharge = machine.getProperty("lv_te:charge");
			if (!currentCharge) {
				return false;
			}
			if (currentCharge < amount) {
				return false;
			}
			if (checkOnly) {
				return true;
			}
			machine.setProperty("lv_te:charge", currentCharge - amount);
			return true;
		} catch (error) {
			//console.error(`Error using fuel for machine ${machine.typeId}:`, error);
			return false;
		}
	}




	static getInputLocation(machine) {
		try {
			const inputConfig = MC.inputOffset[machine.typeId];
			if (!inputConfig) return null;

			const machineRotation = MachineClass.normalizeRotation(machine.getRotation().y);
			const inputOffsetForRotation = inputConfig.find(data => data.orientation === machineRotation);
			if (!inputOffsetForRotation) {
				//console.warn(`No input configuration found for machine ${machine.typeId} with rotation ${machineRotation}`);
				return null;
			}

			// Align machine position to block center
			const machinePosition = {
				x: Math.round(machine.location.x * 2) / 2,
				y: Math.round(machine.location.y),
				z: Math.round(machine.location.z * 2) / 2,
			};

			const inputPosition = {
				x: machinePosition.x + inputOffsetForRotation.x,
				y: machinePosition.y + inputOffsetForRotation.y,
				z: machinePosition.z + inputOffsetForRotation.z
			};

			return inputPosition;

		} catch (error) {
			//console.error(`Error in getInputLocation for machine ${machine.typeId}:`, error);
			return null;
		}
	}

	/**
 * Check if an item can be output to the machine's output inventory.
 * @param {object} machine - The machine entity.
 * @param {ItemStack} itemStack - The item stack to check.
 * @returns {boolean} - Returns true if the item can be output, otherwise false.
 */
	static canOutputItem(machine, itemStack) {
		const outputInventory = MachineClass.getOutputInventory(machine, machine.dimension);
		if (!outputInventory || !outputInventory.container) return false;

		const container = outputInventory.container;
		const containerSize = container.size;

		for (let i = 0; i < containerSize; i++) {
			const existingItem = container.getItem(i);

			// If the slot is empty, the item can be placed
			if (!existingItem) return true;

			// If the slot contains the same type and has space, the item can be stacked
			if (
				existingItem.typeId === itemStack.typeId &&
				existingItem.amount + itemStack.amount <= existingItem.maxAmount
			) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Output an item to the machine's output inventory.
	 * @param {object} machine - The machine entity.
	 * @param {ItemStack} itemStack - The item stack to add to the output inventory.
	 * @returns {boolean} - Returns true if the item was successfully added, otherwise false.
	 */
	static outputItem(machine, itemStack) {
		const outputInventory = MachineClass.getOutputInventory(machine, machine.dimension);
		if (!outputInventory || !outputInventory.container) {
			//console.warn(`outputItem: No valid output inventory found for machine ${machine.typeId}`);
			return false;
		}

		const container = outputInventory.container;
		const containerSize = container.size;

		//console.log(`outputItem: Attempting to output ${itemStack.amount} of ${itemStack.typeId} to machine ${machine.typeId}`);
		//console.log(`outputItem: Output inventory size: ${containerSize}`);

		// Use a placeholder for remaining amount to avoid modifying itemStack.amount directly
		let remainingAmount = itemStack.amount;

		// Attempt to stack the item in existing stacks first
		for (let i = 0; i < containerSize; i++) {
			const existingItem = container.getItem(i);

			if (
				existingItem &&
				existingItem.typeId === itemStack.typeId &&
				existingItem.amount < existingItem.maxAmount
			) {
				const spaceAvailable = existingItem.maxAmount - existingItem.amount;
				const amountToAdd = Math.min(remainingAmount, spaceAvailable);

				//console.log(`outputItem: Found stackable item in slot ${i}, adding ${amountToAdd} items`);

				// Ensure the amount is valid before updating
				if (amountToAdd <= 0) {
					//console.warn(`outputItem: Invalid amount to add (${amountToAdd}). Skipping slot ${i}.`);
					continue;
				}

				// Update the existing item stack
				const updatedItem = existingItem.clone();
				updatedItem.amount = Math.min(existingItem.amount + amountToAdd, 255); // Ensure amount stays within limits

				// Update the container
				container.setItem(i, updatedItem);

				// Decrease the remaining amount
				remainingAmount -= amountToAdd;

				//console.log(`outputItem: Remaining stack to output: ${remainingAmount}`);

				// If the entire stack was added, return success
				if (remainingAmount <= 0) {
					//console.log(`outputItem: Entire stack output successfully`);
					return true;
				}
			}
		}

		// If stacking was not sufficient, attempt to place the remaining items in empty slots
		for (let i = 0; i < containerSize; i++) {
			const existingItem = container.getItem(i);

			// If the slot is empty, place the remaining items
			if (!existingItem) {
				const remainingItemStack = itemStack.clone();
				remainingItemStack.amount = Math.min(remainingAmount, remainingItemStack.maxAmount); // Ensure amount is valid
				container.setItem(i, remainingItemStack);

				//console.log(`outputItem: Remaining items placed in empty slot ${i}`);

				// Decrease the remaining amount
				remainingAmount -= remainingItemStack.amount;

				//console.log(`outputItem: Remaining stack after empty slot placement: ${remainingAmount}`);

				// If the entire stack was added, return success
				if (remainingAmount <= 0) {
					//console.log(`outputItem: Entire stack output successfully`);
					return true;
				}
			}
		}

		// If we reach here, there was not enough space to place the entire stack
		return false;
	}







	// Function to get the output location of a machine
	static getOutputLocation(machine, dimension) {
		try {
			const outputConfig = MC.outputOffset[machine.typeId];
			if (!outputConfig) return null;

			const machineRotation = MachineClass.normalizeRotation(machine.getRotation().y);
			const outputOffsetForRotation = outputConfig.find(data => data.orientation === machineRotation);
			if (!outputOffsetForRotation) return null;

			// Align machine position to block center
			const machinePosition = {
				x: Math.round(machine.location.x * 2) / 2,
				y: Math.round(machine.location.y),
				z: Math.round(machine.location.z * 2) / 2,
			};

			return {
				x: machinePosition.x + outputOffsetForRotation.x,
				y: machinePosition.y + outputOffsetForRotation.y,
				z: machinePosition.z + outputOffsetForRotation.z
			};
		} catch (error) {
			//console.error(`Error in getOutputLocation for machine ${machine.typeId}:`, error);
			return null;
		}
	}

	// Updated getInputInventory to handle both blocks and entities
	static getInputInventory(machine, dimension) {
		try {
			const inputLocation = MachineClass.getInputLocation(machine, dimension);
			if (!inputLocation) return null;

			return MachineClass.getInventoryComponentAtLocation(inputLocation, dimension);
		} catch (error) {
			//console.error(`Error in getInputInventory for machine ${machine.typeId}:`, error);
			return null;
		}
	}

	// Updated getOutputInventory to handle both blocks and entities
	static getOutputInventory(machine, dimension) {
		try {
			const outputLocation = MachineClass.getOutputLocation(machine, dimension);
			if (!outputLocation) return null;

			return MachineClass.getInventoryComponentAtLocation(outputLocation, dimension);
		} catch (error) {
			//console.error(`Error in getOutputInventory for machine ${machine.typeId}:`, error);
			return null;
		}
	}

	// Helper function to get the inventory component of a block or entity
	static getInventoryComponentAtLocation(location, dimension) {
		if (!location || !dimension) {
			return null;
		}

		// Check for a block inventory
		const block = dimension.getBlock(location);
		if (block && block.getComponent("inventory")) {

			return block.getComponent("inventory");
		}

		// Check for entity inventories at the location
		const entities = dimension.getEntities({
			location: {
				x: location.x, // Adjust to match the center of the block
				y: location.y,
				z: location.z,
			},
			maxDistance: 0.9, // Ensure we're targeting entities at the location
		});

		for (const entity of entities) {

			if (entity.getComponent("inventory")) {


				return entity.getComponent("inventory");
			}
		}


		// If neither block nor entity has an inventory, return null
		return null;
	}


	static checkForChestAndHolograms() {
		world.afterEvents.playerPlaceBlock.subscribe((event) => {

			const { block } = event;

			const dimension = block.dimension;
			const blockAbove = dimension.getBlock({
				x: block.location.x,
				y: block.location.y + 1,
				z: block.location.z,
			});

			if (block.typeId == "lv_te:woodcutter") {
				block.dimension.spawnEntity("lv_te:woodcutter_menu", { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 });
			}

			if (blockAbove) {
				// Check for holograms above the placed block
				const hologramEntities = dimension.getEntities({
					location: {
						x: blockAbove.location.x + 0.5,
						y: blockAbove.location.y + 0.5,
						z: blockAbove.location.z + 0.5,
					},
					maxDistance: 0.5,
				});

				for (const entity of hologramEntities) {
					if (entity.typeId === "lv_te:container_hologram") {
						entity.triggerEvent("lv_te:remove_machine");
					}
				}
			}

			if (MC.validContainers.includes(block.typeId)) {
				const inventory = block.getComponent("inventory");
				if (inventory) {
					MachinePipes.checkSurroundingPipesAfterPlacement(block, dimension);
				}
			}
			// Update connectors for the placed pipe
			if (MC.pipeBlocks.includes(block?.typeId)) {
				const pipeEntity = dimension.spawnEntity("lv_te:pipe_dummy", {
					x: block.location.x + 0.5,
					y: block.location.y + 0.5,
					z: block.location.z + 0.5,
				});

				// Store the entity reference for later use
				MachinePipes.registerPipeEntity(block.location, pipeEntity);
				switch (block.typeId) {
					case "lv_te:copper_pipe":
						pipeEntity.triggerEvent('lv_te:spawn_copper_pipe');
						break;
					case "lv_te:advanced_pipe":
						pipeEntity.triggerEvent('lv_te:spawn_advanced_pipe');
						break;
				}
				MachinePipes.checkPlacedPipeSurroundings(block, block.dimension);
			}

			const moduleTypes = ["lv_te:output_module", "lv_te:vacuum_module"];
			if (moduleTypes.includes(block?.typeId)) {
				const facingDirection = block.permutation.getState("minecraft:facing_direction");
				MachinePipes.checkModuleFacingDirectionPipe(block, facingDirection, block.dimension, true);
			}
		});

		world.afterEvents.playerBreakBlock.subscribe((event) => {

			const { block, brokenBlockPermutation } = event;


			if (brokenBlockPermutation.type.id == "lv_te:woodcutter") {
				let entities = block.dimension.getEntities({ location: { x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5 }, maxDistance: 0.5, families: ["lv_te:woodcutter_menu"] });

				entities.forEach(entity => {
					entity.triggerEvent("lv_te:remove_machine")
				});
			}

			if (brokenBlockPermutation.type.id == "lv_te:output_module" || brokenBlockPermutation.type.id == "lv_te:vacuum_module") {
				MachinePipes.checkModuleFacingDirectionPipe(block, brokenBlockPermutation.getState("minecraft:facing_direction"), block.dimension, false);
					
			}
			if (MC.validContainers.includes(brokenBlockPermutation.type.id) || MC.pipeBlocks.includes(brokenBlockPermutation.type.id)) {
				const dimension = block.dimension;

				if (MC.validContainers.includes(brokenBlockPermutation.type.id)) {
					MachinePipes.checkSurroundingPipesAfterRemoval(block, dimension);

				}

				if (MC.pipeBlocks.includes(brokenBlockPermutation.type.id)) {

					const entitiesInBlock = dimension.getEntities({
						location: {
							x: block.location.x + 0.5,
							y: block.location.y + 0.5,
							z: block.location.z + 0.5,
						},
						maxDistance: 0.5,
						families: ["lv.te.pipe"]
					});

					entitiesInBlock.forEach((entity) => {
						try {
							// Drop items and remove entity
							const inventory = entity.getComponent("minecraft:inventory")?.container;
							if (inventory) {
								const entityLocation = {
									x: block.location.x + 0.5,
									y: block.location.y + 0.5,
									z: block.location.z + 0.5,
								};

								// Drop all items in the entity inventory
								for (let i = 0; i < inventory.size; i++) {
									const itemStack = inventory.getItem(i);
									if (itemStack) {
										dimension.spawnItem(itemStack, entityLocation);
										inventory.setItem(i, null);
									}
								}
							}

							// Despawn the dummy entity
							entity.triggerEvent("lv_te:despawn");
							MachinePipes.handlePipeBreak(block, dimension);

						} catch (error) {
							//console.warn(error);
						}
					});
				}
				const entities = dimension.getEntities({ location: block.location, radius: 3 });

				for (const entity of entities) {
					if (MC.machines.includes(entity.typeId)) {
						const inputPosition = MachineClass.getInputLocation(entity);
						const outputPosition = MachineClass.getOutputLocation(entity);

						if (!inputPosition || !outputPosition) return;

						const hasChestBelowInput = MachineClass.isValidContainerAtPosition(dimension, inputPosition);
						const hasHologramAtInput = MachineClass.isHologramAtPosition(dimension, inputPosition);

						const hasChestBelowOutput = MachineClass.isValidContainerAtPosition(dimension, outputPosition);
						const hasHologramAtOutput = MachineClass.isHologramAtPosition(dimension, outputPosition);

						if (!hasChestBelowInput && !hasHologramAtInput) {
							MachineClass.spawnContainerHologram(entity, inputPosition, "lv_te:input_look");
						}

						if (!hasChestBelowOutput && !hasHologramAtOutput) {
							MachineClass.spawnContainerHologram(entity, outputPosition, "lv_te:output_look");
						}
					}
				}
			}

		});
	}

	static spawnContainerHologram(machineEntity, position, eventName) {
		if (!machineEntity || !position || !eventName) {
			return;
		}

		const holoPosition = {
			x: position.x,
			y: position.y + 1,
			z: position.z,
		};

		// Check if a valid container already exists at the position
		if (MachineClass.isValidContainerAtPosition(machineEntity.dimension, holoPosition)) {
			return;
		}

		// Spawn the hologram
		const hologramEntity = machineEntity.dimension.spawnEntity("lv_te:container_hologram", holoPosition);

		// Assign a unique tag to the hologram linked to the machine
		const uniqueTag = `machine_${machineEntity.id}`;
		hologramEntity.addTag(uniqueTag);
		hologramEntity.setRotation({ y: MachineClass.normalizeRotation(machineEntity.getRotation().y), x: 0 });
		hologramEntity.triggerEvent(eventName);
	}

	static isValidContainerAtPosition(dimension, position) {
		const block = dimension.getBlock({ x: position.x, y: position.y, z: position.z });
		if (MC.pipeBlocks.includes(block.typeId)) return true;
		return block && MC.validContainers.includes(block.typeId);
	}


	static getHologramPosition(machineEntity, offsetConfig, rotation) {
		if (!offsetConfig) return null;

		const offset = offsetConfig.find(data => data.orientation === rotation);
		if (!offset) return null;
		const machinePosition = {
			x: Math.round(machineEntity.location.x * 2) / 2,
			y: Math.round(machineEntity.location.y),
			z: Math.round(machineEntity.location.z * 2) / 2,
		};
		return {
			x: machinePosition.x + offset.x,
			y: machinePosition.y + offset.y + 1,
			z: machinePosition.z + offset.z,
		};
	}

	// Helper to check if there's any inventory (block or entity) at a position
	static isInventoryAtPosition(dimension, position) {
		const inventoryComponent = MachineClass.getInventoryComponentAtLocation(position, dimension);
		return inventoryComponent !== null;
	}

	static isHologramAtPosition(dimension, position) {
		const entities = dimension.getEntitiesAtBlockLocation({ x: position.x, y: position.y + 1, z: position.z });
		return entities.some(entity => entity.typeId === 'lv_te:container_hologram');
	}

	// Utility function to despawn holograms
	static despawnHolograms(machineEntity) {
		const uniqueTag = `machine_${machineEntity.id}`;
		const dimension = machineEntity.dimension;

		// Find and remove all holograms with the unique tag
		const entities = dimension.getEntities();
		for (const entity of entities) {
			if (entity.hasTag(uniqueTag)) {
				entity.triggerEvent("lv_te:remove_machine");
			}
		}
	}

	static getTargetPosition(location, facing, reverse = false) {
		// Define offsets for each facing direction
		const offsets = {
			north: { x: 0, y: 0, z: -1 },
			south: { x: 0, y: 0, z: 1 },
			east: { x: 1, y: 0, z: 0 },
			west: { x: -1, y: 0, z: 0 },
			up: { x: 0, y: 1, z: 0 },
			down: { x: 0, y: -1, z: 0 },
		};

		// Validate the provided facing direction
		const offset = offsets[facing];
		if (!offset) return null;

		// Reverse the offset if the reverse flag is true
		const adjustedOffset = reverse
			? { x: -offset.x, y: -offset.y, z: -offset.z }
			: offset;

		// Calculate the target position
		return {
			x: location.x + adjustedOffset.x,
			y: location.y + adjustedOffset.y,
			z: location.z + adjustedOffset.z,
		};
	}


	// Utility function
	static removeTimerForEntity(entityId) {
		if (MachineClass.crackingTimers.has(entityId)) {
			system.clearJob(MachineClass.crackingTimers.get(entityId));
			MachineClass.crackingTimers.delete(entityId);
		}
	}
	// Utility function
	static resetCracking(entity) {
		try {
			const entityId = entity.id;

			// If a timer exists for this entity, clear it
			if (MachineClass.crackingTimers.has(entityId)) {
				system.clearJob(MachineClass.crackingTimers.get(entityId));
			}

			// Schedule a new timer to reset the cracking property
			const timer = system.runTimeout(() => {
				try {
					const crackingState = entity.getProperty('lv.te:cracking');
					if (crackingState > 0) {
						entity.setProperty('lv.te:cracking', 0); // Reset to 0
					}
					MachineClass.crackingTimers.delete(entityId); // Remove timer from the map
				} catch (error) {
				}
			}, 30); // 30 ticks = 1.5 seconds

			// Store the timer job ID in the Map
			MachineClass.crackingTimers.set(entityId, timer);
		} catch (error) {
		}
	}

	// Function to normalize rotation to 0, 90, 180, or 270
	static normalizeRotation(rotation) {
		// Ensure the rotation is always positive
		const positiveRotation = ((rotation % 360) + 360) % 360;

		// Find the nearest multiple of 90
		const nearestRotation = Math.round(positiveRotation / 90) * 90;

		return nearestRotation % 360; // Ensure it's within the 0-359 range
	}

	static machinesBlock(source, rotation, block = 'lv_te:custom_barrier', permutation = {}) {
		let { x, y, z } = source.location;

		// Normalize the rotation
		const normalizedRotation = this.normalizeRotation(rotation);

		const machines = source.typeId;
		const barrierBlockArray = MC.machinesBlockbox[machines];

		if (!barrierBlockArray) {
			return;
		}

		const barrierObj = barrierBlockArray.find(obj => Math.abs(obj.orientation - normalizedRotation) < 1);

		if (barrierObj) {
			const { xOffSet, yOffSet, zOffSet, xPlus, zPlus } = barrierObj;
			let targetX = x + xOffSet;
			const targetY = y + yOffSet;
			let targetZ = z + zOffSet;

			if (targetX < x) [x, targetX] = [targetX, x];
			if (targetZ < z) [z, targetZ] = [targetZ, z];

			// Pass the unique ID as part of the permutation or use an external map
			permutation = { ...permutation }; // Include the entity ID in the permutation

			this.fillBlock(source, block, (x + xPlus), y, (z + zPlus), targetX, targetY, targetZ, permutation);
		}
	}

	static fillBlock(source, blockPerm, xFrom, yFrom, zFrom, xTo, yTo, zTo, permutation = {}) {
		// Ensure yFrom and yTo are within the specified range
		yFrom = Math.max(-64, yFrom);
		yTo = Math.min(320, yTo);

		for (let i = xFrom; i <= xTo; i++) {
			for (let j = yFrom; j <= yTo; j++) {
				for (let k = zFrom; k <= zTo; k++) {
					const block = source.dimension.getBlock({ x: i, y: j, z: k });
					if (block.permutation.matches('minecraft:air') || block.permutation.matches('lv_te:custom_barrier') || block.permutation.matches('lv_te:invis_cooking_pot') || block.permutation.matches('lv_te:half_custom_barrier')) {
						// Add the unique entity ID to the block permutation
						const newPermutation = BlockPermutation.resolve(blockPerm, permutation);
						block.setPermutation(newPermutation);
					}
				}
			}
		}
	}


	static removeBlocks(source, rotation) {
		let { x, y, z } = source.location;

		// Normalize the rotation
		const normalizedRotation = this.normalizeRotation(rotation);

		const machines = source.typeId;
		const barrierBlockArray = MC.machinesBlockbox[machines];

		if (!barrierBlockArray) {
			return;
		}

		const barrierObj = barrierBlockArray.find(obj => Math.abs(obj.orientation - normalizedRotation) < 1);

		if (barrierObj) {
			const { xOffSet, yOffSet, zOffSet, xPlus, zPlus } = barrierObj;
			let targetX = x + xOffSet;
			const targetY = y + yOffSet;
			let targetZ = z + zOffSet;

			if (targetX < x) [x, targetX] = [targetX, x];
			if (targetZ < z) [z, targetZ] = [targetZ, z];

			// Remove blocks by setting them to air
			this.fillBlock(source, 'minecraft:air', (x + xPlus), y, (z + zPlus), targetX, targetY, targetZ);
		} else {
			console.log("test");

		}
	}

}
