export const machines = [
    "lv_te:smelting_machine",
    "lv_te:oil_extractor",
    "lv_te:automatic_harvester",
    "lv_te:ore_generator",
    "lv_te:automatic_drill",
    "lv_te:advanced_automatic_drill",
    "lv_te:advanced_ore_generator",
    "lv_te:automatic_fisher",
    "lv_te:cooking_pot",
    "lv_te:auto_treecutter",
    "lv_te:charging_station",
    "lv_te:oil_refinery"
];

export const pipeBlocks = [
    "lv_te:copper_pipe",
    "lv_te:advanced_pipe"
];


//INPUT OUTPUT MACHINES
export const machineConfigs = {
    "lv_te:smelting_machine": {
        fuelUsage: 2, // Fuel required per siphon
        allowedInputs: [
            "minecraft:iron_ore",
            "minecraft:gold_ore",
            "minecraft:copper_ore",
            "minecraft:raw_iron",
            "minecraft:raw_gold",
            "minecraft:raw_copper",
            "minecraft:sand",
            "minecraft:red_sand",
            "minecraft:cobblestone",
            "minecraft:stone",
            "minecraft:clay",
            "minecraft:netherrack",
            "minecraft:ancient_debris",
            "minecraft:kelp",
            "minecraft:potato",
            "minecraft:raw_mutton",
            "minecraft:raw_beef",
            "minecraft:raw_porkchop",
            "minecraft:raw_chicken",
            "minecraft:raw_rabbit",
            "minecraft:raw_cod",
            "minecraft:raw_salmon"
        ], // Items this machine can siphon
        outputItems: {
            "minecraft:iron_ore": {
                typeId: "minecraft:iron_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:gold_ore": {
                typeId: "minecraft:gold_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:copper_ore": {
                typeId: "minecraft:copper_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_iron": {
                typeId: "minecraft:iron_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_gold": {
                typeId: "minecraft:gold_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_copper": {
                typeId: "minecraft:copper_ingot",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:sand": {
                typeId: "minecraft:glass",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:red_sand": {
                typeId: "minecraft:glass",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:cobblestone": {
                typeId: "minecraft:stone",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:stone": {
                typeId: "minecraft:smooth_stone",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:clay": {
                typeId: "minecraft:brick",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:netherrack": {
                typeId: "minecraft:nether_brick",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:ancient_debris": {
                typeId: "minecraft:netherite_scrap",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:kelp": {
                typeId: "minecraft:dried_kelp",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:potato": {
                typeId: "minecraft:baked_potato",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_mutton": {
                typeId: "minecraft:cooked_mutton",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_beef": {
                typeId: "minecraft:steak",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_porkchop": {
                typeId: "minecraft:cooked_porkchop",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_chicken": {
                typeId: "minecraft:cooked_chicken",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_rabbit": {
                typeId: "minecraft:cooked_rabbit",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_cod": {
                typeId: "minecraft:cooked_cod",
                inputAmount: 1,
                outputAmount: 1
            },
            "minecraft:raw_salmon": {
                typeId: "minecraft:cooked_salmon",
                inputAmount: 1,
                outputAmount: 1
            }
        },

    },
    "lv_te:oil_refinery": {
        fuelUsage: 0,
        allowedInputs: [
            "lv_te:oil"
        ], // Items this machine can siphon
        outputItems: {
            "lv_te:oil": {
                typeId: "lv_te:gasoline",
                inputAmount: 4,
                outputAmount: 1
            }
        },

    },
    "lv_te:ore_generator": {
        fuelUsage: 10,
    },
    "lv_te:advanced_ore_generator": {
        fuelUsage: 10,
    },
    "lv_te:auto_treecutter": {
        fuelUsage: 10,
    },
    // Add more machine types as needed
};



export const validContainers = ['minecraft:chest', 'minecraft:trapped_chest', 'minecraft:furnace', 'minecraft:barrel', 'minecraft:hopper', 'minecraft:crafter'];


export const hasInput = [
    "lv_te:smelting_machine",
    "lv_te:oil_refinery"
];
export const hasOutput = [
    "lv_te:smelting_machine",
    "lv_te:oil_refinery"
];


export const inputOffset = {
    "lv_te:smelting_machine": [
        { orientation: 0, x: -1, y: 0, z: 0 },  // Input to the left when front is facing +Z
        { orientation: 90, x: 0, y: 0, z: -1 }, // Input to the left when front is facing +X
        { orientation: 180, x: 1, y: 0, z: 0 }, // Input to the left when front is facing -Z
        { orientation: 270, x: 0, y: 0, z: 1 }  // Input to the left when front is facing -X
    ],
    "lv_te:oil_refinery": [
        { orientation: 0, x: -1, y: 0, z: 0 },  // Input to the left when front is facing +Z
        { orientation: 90, x: 0, y: 0, z: -1 }, // Input to the left when front is facing +X
        { orientation: 180, x: 1, y: 0, z: 0 }, // Input to the left when front is facing -Z
        { orientation: 270, x: 0, y: 0, z: 1 }  // Input to the left when front is facing -X
    ]
};


export const outputOffset = {
    "lv_te:smelting_machine": [
        { orientation: 0, x: 1, y: 0, z: 0 },  // Input to the left when front is facing +Z
        { orientation: 90, x: 0, y: 0, z: 1 }, // Input to the left when front is facing +X
        { orientation: 180, x: -1, y: 0, z: 0 }, // Input to the left when front is facing -Z
        { orientation: 270, x: 0, y: 0, z: -1 }  // Input to the left when front is facing -X
    ],
    "lv_te:oil_refinery": [
        { orientation: 0, x: 1, y: 0, z: 0 },  // Input to the left when front is facing +Z
        { orientation: 90, x: 0, y: 0, z: 1 }, // Input to the left when front is facing +X
        { orientation: 180, x: -1, y: 0, z: 0 }, // Input to the left when front is facing -Z
        { orientation: 270, x: 0, y: 0, z: -1 }  // Input to the left when front is facing -X
    ]
};

export const machinesBlockbox = {
    "lv_te:cooking_pot": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:auto_treecutter": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:smelting_machine": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:oil_refinery": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:automatic_harvester": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:ore_generator": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:automatic_drill": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:advanced_automatic_drill": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:advanced_ore_generator": [
        { orientation: 0, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 }
    ],
    "lv_te:oil_extractor": [
        { orientation: 0, xOffSet: -1, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 90, xOffSet: 0, yOffSet: 0, zOffSet: -1, xPlus: 0, zPlus: 0 },
        { orientation: 180, xOffSet: 1, yOffSet: 0, zOffSet: 0, xPlus: 0, zPlus: 0 },
        { orientation: 270, xOffSet: 0, yOffSet: 0, zOffSet: 1, xPlus: 0, zPlus: 0 }
    ]
};

export const ORE_GEN_WEIGHTS = [
    { name: "minecraft:stone", weight: 40 },
    { name: "minecraft:gravel", weight: 15 },
    { name: "minecraft:diorite", weight: 15 },
    { name: "minecraft:granite", weight: 15 },
    { name: "minecraft:andesite", weight: 15 },
    { name: "minecraft:dirt", weight: 20 },
    { name: "minecraft:coal_ore", weight: 6 },
    { name: "minecraft:iron_ore", weight: 2 }
];

export const ADV_ORE_GEN_WEIGHTS = [
    { name: "minecraft:stone", weight: 40 },
    { name: "minecraft:gravel", weight: 15 },
    { name: "minecraft:diorite", weight: 15 },
    { name: "minecraft:granite", weight: 15 },
    { name: "minecraft:andesite", weight: 15 },
    { name: "minecraft:dirt", weight: 20 },
    { name: "minecraft:coal_ore", weight: 8 },
    { name: "minecraft:iron_ore", weight: 4 },
    { name: "minecraft:gold_ore", weight: 1 }
];



export const FISH_CATCH_WEIGHTS = [
    { name: "minecraft:kelp", weight: 20 },
    { name: "minecraft:cod", weight: 30 },
    { name: "minecraft:salmon", weight: 30 },
    { name: "minecraft:tropical_fish", weight: 25 },
    { name: "minecraft:pufferfish", weight: 15 },
    { name: "minecraft:ink_sac", weight: 10 },
    { name: "minecraft:glowing_ink_sac", weight: 5 }
];


export const DrillableBlocks = [
    { blockType: "minecraft:stone", outcomes: [{ itemType: "minecraft:cobblestone", quantity: 1 }] },
    { blockType: "minecraft:cobblestone", outcomes: [{ itemType: "minecraft:cobblestone", quantity: 1 }] },
    { blockType: "minecraft:gravel", outcomes: [{ itemType: "minecraft:gravel", quantity: 1 }] },
    { blockType: "minecraft:diorite", outcomes: [{ itemType: "minecraft:diorite", quantity: 1 }] },
    { blockType: "minecraft:granite", outcomes: [{ itemType: "minecraft:granite", quantity: 1 }] },
    { blockType: "minecraft:andesite", outcomes: [{ itemType: "minecraft:andesite", quantity: 1 }] },
    { blockType: "minecraft:dirt", outcomes: [{ itemType: "minecraft:dirt", quantity: 1 }] },
    { blockType: "minecraft:coal_ore", outcomes: [{ itemType: "minecraft:coal", quantity: 1 }] },
    { blockType: "minecraft:iron_ore", outcomes: [{ itemType: "minecraft:raw_iron", quantity: 1 }] },
    { blockType: "minecraft:copper_ore", outcomes: [{ itemType: "minecraft:raw_copper", quantity: 1 }] },
    { blockType: "minecraft:gold_ore", outcomes: [{ itemType: "minecraft:raw_gold", quantity: 1 }] },
    { blockType: "minecraft:redstone_ore", outcomes: [{ itemType: "minecraft:redstone", quantity: 3 }] },
    { blockType: "minecraft:lit_redstone_ore", outcomes: [{ itemType: "minecraft:redstone", quantity: 3 }] },
    { blockType: "minecraft:lapis_ore", outcomes: [{ itemType: "minecraft:lapis_lazuli", quantity: 2 }] },
    { blockType: "minecraft:emerald_ore", outcomes: [{ itemType: "minecraft:emerald", quantity: 1 }] },
    { blockType: "minecraft:diamond_ore", outcomes: [{ itemType: "minecraft:diamond", quantity: 1 }] },
    { blockType: "minecraft:quartz_ore", outcomes: [{ itemType: "minecraft:quartz", quantity: 1 }] },
    { blockType: "minecraft:ancient_debris", outcomes: [{ itemType: "minecraft:ancient_debris", quantity: 1 }] }
];

export const HarvestableBlocks = [
    { blockType: "minecraft:wheat", maxGrowthStage: 7, outcomes: [{ itemType: "minecraft:wheat", quantity: 2 }, { itemType: "minecraft:wheat_seeds", quantity: 1 }], seeds: "minecraft:wheat" },
    { blockType: "minecraft:carrots", maxGrowthStage: 7, outcomes: [{ itemType: "minecraft:carrot", quantity: 2 }], seeds: "minecraft:carrots" },
    { blockType: "minecraft:potatoes", maxGrowthStage: 7, outcomes: [{ itemType: "minecraft:potato", quantity: 2 }], seeds: "minecraft:potatoes" },
    { blockType: "minecraft:beetroot", maxGrowthStage: 7, outcomes: [{ itemType: "minecraft:beetroot", quantity: 2 }, { itemType: "minecraft:beetroot_seeds", quantity: 1 }], seeds: "minecraft:beetroot" },
    { blockType: "minecraft:nether_wart", maxGrowthStage: 3, outcomes: [{ itemType: "minecraft:nether_wart", quantity: 2 }], seeds: "minecraft:nether_wart" },
    { blockType: "minecraft:cocoa", maxGrowthStage: 2, outcomes: [{ itemType: "minecraft:cocoa_beans", quantity: 3 }], seeds: "minecraft:cocoa" },
    { blockType: "minecraft:melon", outcomes: [{ itemType: "minecraft:melon_slice", quantity: 9 }] },
    { blockType: "minecraft:pumpkin", outcomes: [{ itemType: "minecraft:pumpkin", quantity: 1 }] }
];


export const machinesData = {
    "Pipes": {
        description: "Used for transporting resources between machines. \n\n§6How to Use:\n§rYou can connect pipes with other pipes or any kind of container, if a pipe is connected successfully you will see it visually connect. \n\n§6Pipe Specifics: §r\nCopper Pipes behave like copper meaning they will oxidate, you can stop it using Honeycomb or strip it off using axes. \nAdvanced Pipes can be colored using red, blue, pink, black, white, and green dye.",
        howToGet: "§lCopper Pipes:§r Crafted using 2 Copper Ingots \n§lAdvanced Pipes:§r Crafted using 2 Steel.",
        image: "textures/levelatics/tech/ui/pipe.png",
    },
    "Vacuum Pipe Module": {
        description: "Used for transporting resources between machines.",
        howToGet: "Crafted using Steel and Hopper.",
        image: "textures/levelatics/tech/ui/vacuum_module.png",
    },
    "Output Pipe Module": {
        description: "Used for transporting resources between machines.",
        howToGet: "Crafted using Steel and Dispenser.",
        image: "textures/levelatics/tech/ui/output_module.png",
    },
    "Automatic Drill": {
        description: "Drills the block below itself automatically.",
        howToGet: "Crafted using wires, steel ingots, sticky piston and quantum core.",
        image: "textures/levelatics/tech/ui/automatic_drill.png",
    },
    "Advanced Automatic Drill": {
        description: "A more efficient and faster automatic drill.",
        howToGet: "Crafted using wires, titanium, a sticky piston and quantum core.",
        image: "textures/levelatics/tech/ui/advanced_automatic_drill.png",
    },
    "Ore Generator": {
        description: "Generates ores over time.",
        howToGet: "Crafted using wires, steel ingots and quantum core.",
        image: "textures/levelatics/tech/ui/ore_generator.png",
    },
    "Advanced Ore Generator": {
        description: "Generates higher-tier ores faster.",
        howToGet: "Crafted using wires, titanium and quantum core",
        image: "textures/levelatics/tech/ui/advanced_ore_generator.png",
    },
    "Uncrafter": {
        description: "A reverse crafting table.",
        howToGet: "Crafted using a crafting table and quantum core.",
        image: "textures/levelatics/tech/ui/uncrafter.png",
    },
    "Auto Treecutter": {
        description: "Automatically generates trees and cuts them down.",
        howToGet: "Crafted using an hopper, observer, iron axe, oak sapling and quantum core",
        image: "textures/levelatics/tech/ui/auto_treecutter.png",
    },
    "Automatic Fisher": {
        description: "Catches fish automatically.",
        howToGet: "Crafted using a Hopper, Observer, Rod and Quantum Core.",
        image: "textures/levelatics/tech/ui/automatic_fisher.png",
    },
    "Oil Extractor": {
        description: "Automatically generates oil.",
        howToGet: "Crafted using a Hopper, Quantum core, Copper Ingots, Observer and Blaze Powder.",
        image: "textures/levelatics/tech/ui/oil_extractor.png",
    },
    "Oil Refinery": {
        description: "Crafts gasoline out of oil.",
        howToGet: "Crafted using Iron Ingots, Quartz and Redstone.",
        image: "textures/levelatics/tech/ui/oil_refinery.png",
    },
    "Smelting Machine": {
        description: "Smelts ores very fast.",
        howToGet: "Crafted using a blast furnace, oberserver, quantum core and iron ingot.",
        image: "textures/levelatics/tech/ui/smelting_machine.png",
    },
    "Woodcutter": {
        description: "A wooden version of the stonecutter.",
        howToGet: "Crafted using oak planks and an iron ingot.",
        image: "textures/levelatics/tech/ui/woodcutter.png",
    },
    "Automatic Harvester": {
        description: "Automatically harvests and re-plants your crops.",
        howToGet: "Crafted using a craved pumpkin, iron hoe, hopper, observer and a quantum core.",
        image: "textures/levelatics/tech/ui/automatic_harvester.png",
    },
    "Cooking Pot": {
        description: "Used to cook tasty meals.",
        howToGet: "Crafted using a cauldron, campfire, sticks.",
        image: "textures/levelatics/tech/ui/cooking_pot.png",
    },
    "Solidifier": {
        description: "Solidifier solidifies blocks such as water to ice, or lava to magma, learn more about the specific recipes inside the recipe book while in the Solidifier menu.",
        howToGet: "Crafted using a furnace, iron ingot, hopper and packed ice.",
        image: "textures/levelatics/tech/ui/solidifier.png",
    },
    "Manual Ore Extractor": {
        description: "Used to extract ores out of sand, dirt or gravel.",
        howToGet: "Crafted using a composter, iron ingots and a quantum core.",
        image: "textures/levelatics/tech/ui/manual_ore_extractor.png",
    },
    "S.A.R.A.": {
        description: "A minion that helps you to collect dropped items.",
        howToGet: "Crafted using wires, quantum core, wires, steel ingots and a chest.",
        image: "textures/levelatics/tech/items/sara.png",
    },
    "F.R.E.D.": {
        description: "A minion that automatically fills up machines with gasoline.",
        howToGet: "Crafted using a quantum core, wires, steel ingots and a dispenser.",
        image: "textures/levelatics/tech/items/fred.png",
    },
    "T.E.C.H. Drill": {
        description: "Rideable Mining Drill Vehicle, that can be used to mine big mineshafts.",
        howToGet: "Crafted using tech shards, iron blocks and a quantum core.",
        image: "textures/levelatics/tech/items/tech_drill.png",
    },
    "T.E.C.H. Mech Suit": {
        description: "A rideable Mech Suit with the ability to knock away any enemy.",
        howToGet: "Crafted using tech shards and titanium ingots.",
        image: "textures/levelatics/tech/items/tech_mecha.png",
    },
    // Add more machines as needed
};

export const itemsData = {
    "B.O.O.M. TNT": {
        description: "Use to create a big B.O.O.M!",
        howToGet: "Crafted using wires, TNT and quantum core.",
        image: "textures/levelatics/tech/ui/boom_tnt.png",
    },
    "Boosting Pad": {
        description: "Use for a boost.",
        howToGet: "Crafted using a quantum core, heavy pressure plate and a wire.",
        image: "textures/levelatics/tech/ui/boosting_pad.png",
    },
    "Oil": {
        description: "A base ingredient for crafting gasoline.",
        howToGet: "Extracted from oil generator.",
        image: "textures/levelatics/tech/items/oil.png",
    },
    "Gasoline": {
        description: "Fuel for advanced machinery.",
        howToGet: "Crafted or refined from oil in an oil refinery.",
        image: "textures/levelatics/tech/items/gasoline.png",
    },
    "Quantum Core": {
        description: "The core of advanced tech machinery.",
        howToGet: "Crafted using prismarine shard, wires and prismarine crystals.",
        image: "textures/levelatics/tech/items/quantum_core.png",
    },
    "T.E.C.H. Backpack": {
        description: "An advanced backpack for extra storage. §cCan even carry one Shulker Box!",
        howToGet: "Crafted using backpack, quantum core and tech shards.",
        image: "textures/levelatics/tech/items/tech_backpack.png",
    },
    "T.E.C.H. Helmet": {
        description: "Advanced helmet with enhanced vision.",
        howToGet: "Crafted using netherite helmet and tech template.",
        image: "textures/levelatics/tech/items/tech_helmet.png",
    },
    "T.E.C.H. Axe": {
        description: "A high-tech axe for efficient resource harvesting.",
        howToGet: "Crafted using sticks and tech shards.",
        image: "textures/levelatics/tech/items/tech_axe.png",
    },
    "T.E.C.H. Gauntlet": {
        description: "A high-tech farming tool for efficient resource harvesting.",
        howToGet: "Crafted using tech shards and a netherstar.",
        image: "textures/levelatics/tech/items/tech_gauntlet.png",
    },
    "T.E.C.H. Goggles": {
        description: "High-tech googles that improve your vision at night.",
        howToGet: "Crafted using quantum core, black stained glass pane and titanium.",
        image: "textures/levelatics/tech/items/tech_googles.png",
    },
    "T.E.C.H. Jetpack": {
        description: "Use to fly or hover around!",
        howToGet: "Crafted using eyltra, tech shards, quantum core and gasoline.",
        image: "textures/levelatics/tech/items/tech_jetpack.png",
    },
    "T.E.C.H. Shards": {
        description: "A high-tech crafting material used for powerful gear.",
        howToGet: "Crafted using quantum core and titanium.",
        image: "textures/levelatics/tech/items/tech_shards.png",
    },
    "T.E.C.H. Template": {
        description: "Use to upgrade your netherite into T.E.C.H gear.",
        howToGet: "Crafted using tech shards and titanium template.",
        image: "textures/levelatics/tech/items/tech_template.png",
    },
    "Backpack": {
        description: "An item to expand your inventory storage. §7Can be worn on the back!",
        howToGet: "Crafted using leather, tech shards, chest and steel.",
        image: "textures/levelatics/tech/items/backpack.png",
    },
    "Miner Helmet": {
        description: "Provides light in dark areas.",
        howToGet: "Crafted using stick, wires and torches.",
        image: "textures/levelatics/tech/items/miner_helmet.png",
    },
    "Steel Axe": {
        description: "A durable axe for harvesting resources.",
        howToGet: "Crafted using sticks and steel.",
        image: "textures/levelatics/tech/items/steel_axe.png",
    },
    "Steel Shovel": {
        description: "A durable shovel for harvesting resources.",
        howToGet: "Crafted using sticks and steel.",
        image: "textures/levelatics/tech/items/steel_shovel.png",
    },
    "Steel Pickaxe": {
        description: "A durable pickaxe for harvesting resources.",
        howToGet: "Crafted using sticks and steel.",
        image: "textures/levelatics/tech/items/steel_pickaxe.png",
    },
    "Steel Chestplate": {
        description: "Provides strong protection against attacks.",
        howToGet: "Crafted using steel.",
        image: "textures/levelatics/tech/items/steel_chestplate.png",
    },
    "Steel Boots": {
        description: "Sturdy boots for tough terrain.",
        howToGet: "Crafted using steel.",
        image: "textures/levelatics/tech/items/steel_boots.png",
    },
    "Steel Helmet": {
        description: "A protective helmet made of steel.",
        howToGet: "Crafted using steel.",
        image: "textures/levelatics/tech/items/steel_helmet.png",
    },
    "Steel Leggings": {
        description: "Durable leggings to withstand damage.",
        howToGet: "Crafted using steel.",
        image: "textures/levelatics/tech/items/steel_leggings.png",
    },
    "Titanium Shovel": {
        description: "A very powerful shovel.",
        howToGet: "Crafted using sticks and titanium.",
        image: "textures/levelatics/tech/items/titanium_shovel.png",
    },
    "Titanium Axe": {
        description: "An extremly durable axe.",
        howToGet: "Crafted using sticks and titanium.",
        image: "textures/levelatics/tech/items/titanium_axe.png",
    },
    "Titanium Pickaxe": {
        description: "A very fast pickaxe made from titanium.",
        howToGet: "Crafted using sticks and titanium.",
        image: "textures/levelatics/tech/items/titanium_pickaxe.png",
    },
    "Titanium Helmet": {
        description: "A strong helmet made from titanium.",
        howToGet: "Crafted using titanium template and steel helmet.",
        image: "textures/levelatics/tech/items/titanium_helmet.png",
    },
    "Titanium Chestplate": {
        description: "A strong chestplate made from titanium.",
        howToGet: "Crafted using titanium template and steel chestplate.",
        image: "textures/levelatics/tech/items/titanium_chestplate.png",
    },
    "Titanium Leggings": {
        description: "A strong leggings made from titanium.",
        howToGet: "Crafted using titanium template and steel leggings.",
        image: "textures/levelatics/tech/items/titanium_leggings.png",
    },
    "Titanium Boots": {
        description: "Durable boots made from titanium.",
        howToGet: "Crafted using titanium template and steel boots.",
        image: "textures/levelatics/tech/items/titanium_boots.png",
    },
    "Bacon and Eggs": {
        description: "A hearty meal to restore hunger and health.",
        howToGet: "Cooked using eggs, porkchop and wooden plate.",
        image: "textures/levelatics/tech/items/bacon_eggs.png",
    },
    "Mixed Grill": {
        description: "A delicious combination of grilled meats.",
        howToGet: "Cooked using beef, chicken, porkchop and a wooden bowl.",
        image: "textures/levelatics/tech/items/mixed_grill.png",
    },
    "Pasta": {
        description: "A nutritious meal to restore health.",
        howToGet: "Cooked using milk bucket, wheat, brown mushroom and a wooden bowl.",
        image: "textures/levelatics/tech/items/pasta.png",
    },
    "Sushi": {
        description: "A nutritious meal to restore health.",
        howToGet: "Cooked using salomon, dried kelp and a wooden plate.",
        image: "textures/levelatics/tech/items/sushi.png",
    },
    "Smoothie": {
        description: "A refreshing drink to restore energy.",
        howToGet: "Cooked using apple, melon slices, golden carrot and a wooden cup.",
        image: "textures/levelatics/tech/items/smoothie.png",
    },
    "Spicy Stew": {
        description: "A hot stew that boosts resistance.",
        howToGet: "Cooked using nether wart, beef and a wooden bowl.",
        image: "textures/levelatics/tech/items/spicy_stew.png",
    },
    "Steak & Veggies": {
        description: "A hot stew that boosts resistance.",
        howToGet: "Cooked using potato, beef, carrot, apple and a wooden plate.",
        image: "textures/levelatics/tech/items/steak_veggies.png",
    },
    "Wooden Bowl": {
        description: "A basic bowl for crafting recipes.",
        howToGet: "Crafted using sticks.",
        image: "textures/levelatics/tech/items/wooden_bowl.png",
    },
    "Wooden Cup": {
        description: "A basic cup for crafting recipes.",
        howToGet: "Crafted using sticks.",
        image: "textures/levelatics/tech/items/wooden_cup.png",
    },
    "Wooden Plate": {
        description: "A simple plate for serving food.",
        howToGet: "Crafted using sticks.",
        image: "textures/levelatics/tech/items/wooden_plate.png",
    },
    // Add all Items from the image
};