import { ActionFormData } from "@minecraft/server-ui";
import { system } from "@minecraft/server";
import * as MC from "./MachinesConstants.js";

class TechGuide {
    static openMenu(source) {
        this.showMainMenu(source);
    }

    static showMainMenu(player) {
        const menuForm = new ActionFormData()
            .title("§lTech Craft - Info Menu")
            .body(
                "Welcome to the §c§lTech Craft - Info Menu§r! Navigate through the pages to learn all about the new Machines, Items, and Companions and how to craft them!",
            )
            .button("Machines & Tech", "textures/levelatics/tech/ui/blocks.png")
            .button(
                "Items & Equipment",
                "textures/levelatics/tech/ui/tools.png",
            )
            .button("Feedback", "textures/levelatics/tech/ui/feedback.png")
            .button(
                "Settings / Debug",
                "textures/levelatics/tech/ui/settings.png",
            );

        menuForm.show(player).then((response) => {
            if (response.canceled) return;

            switch (response.selection) {
                case 0:
                    this.showMachinesPage(player);
                    break;
                case 1:
                    this.showItemsPage(player);
                    break;
                case 2:
                    this.showFeedbackPage(player);
                    break;
                case 3:
                    this.showSettingsPage(player);
                    break;
            }
        });
    }
    static showFeedbackPage(player) {
        const feedbackForm = new ActionFormData()
            .title("§lFeedback")
            .body(
                "§c§lThank you§r for downloading our Tech Craft Add-On! We truly appreciate your support.\n\n" +
                    "§o§oIf you encounter any bugs, issues, or have suggestions for future updates, feel free to reach out to us on any of our social media platforms or join our Discord community.§r\n\n" +
                    "§e§lOur Socials:§r\n" +
                    "§f§lInstagram: §r§o@levelatics\n" +
                    "§f§lTwitter/X: §r§o@levelatics\n" +
                    "§f§lYouTube: §r§o@levelatics\n\n" +
                    "§e§lJoin our Community:§r\n" +
                    "§f§lDiscord: §r§odiscord.levelatics.com",
            )
            .button("Go Back", "textures/levelatics/tech/ui/back.png"); // Ensure Go Back is last

        feedbackForm.show(player).then((response) => {
            if (response.canceled) return;

            switch (response.selection) {
                case 0: // Go Back button
                    this.showMainMenu(player);
                    break;
            }
        });
    }
    static showSettingsPage(player) {
        const feedbackForm = new ActionFormData()
            .title("§lSettings / Debug")
            .body(
                "§6§lHow to use this menu:\n§r§c!! If F.R.E.D. stops moving to machines that need fuel, use this fix. !!\n\n" +
                    "§7Press the button below to attempt a fix.\nIf it still doesn't work, try fueling a machine manually first.\n",
            )
            .button("Fix F.R.E.D. not fueling machines.")
            .button("Go Back", "textures/levelatics/tech/ui/back.png");

        feedbackForm.show(player).then((response) => {
            if (response.canceled) return;

            switch (response.selection) {
                case 0: // Fix F.R.E.D.
                    {
                        const machines = player.dimension.getEntities({
                            families: ["lv_te:charge_bar"],
                        });

                        for (const machine of machines) {
                            const charge = machine.getProperty("lv_te:charge");
                            if (typeof charge === "number" && charge < 5) {
                                machine.runCommand(
                                    "scriptevent lv.te:machines.spawnFuelDummy",
                                );
                            }
                        }
                    }
                    break;

                case 1: // Go Back
                    this.showMainMenu(player);
                    break;
            }
        });
    }

    static showMachinesPage(player) {
        const machinesForm = new ActionFormData()
            .title("§lMachines and Tech")
            .body("Choose a machine to learn more about it!");

        // Dynamically add buttons for each machine
        Object.keys(MC.machinesData).forEach((machineName) => {
            const machine = MC.machinesData[machineName];
            machinesForm.button(machineName, machine.image);
        });

        machinesForm.button("Go Back", "textures/levelatics/tech/ui/back.png");

        machinesForm.show(player).then((response) => {
            if (
                response.canceled ||
                response.selection === Object.keys(MC.machinesData).length
            ) {
                this.showMainMenu(player); // Adjust this function to go back to your main menu
            } else {
                const selectedMachineName =
                    Object.keys(MC.machinesData)[response.selection];
                this.showMachineSpecificPage(player, selectedMachineName);
            }
        });
    }

    static showMachineSpecificPage(player, machineName) {
        const machine = MC.machinesData[machineName] || {
            description: "Details not available.",
            howToGet: "How to obtain this machine is not provided.",
            image: "textures/levelatics/tech/ui/default.png",
        };

        const machineForm = new ActionFormData()
            .title(`§l${machineName}`)
            .body(
                `§6Description:§r\n${machine.description}\n\n§6How to Get:§r\n${machine.howToGet}`,
            )
            .button("Go Back", machine.image);

        machineForm.show(player).then((response) => {
            if (!response.canceled) {
                this.showMachinesPage(player); // Go back to the machines page
            }
        });
    }

    static showItemsPage(player) {
        const itemsForm = new ActionFormData()
            .title("§lItems & Equipment")
            .body("Choose a item or equipment to learn more about it!");

        // Dynamically add buttons for each machine
        Object.keys(MC.itemsData).forEach((itemName) => {
            const item = MC.itemsData[itemName];
            itemsForm.button(itemName, item.image);
        });

        itemsForm.button("Go Back", "textures/levelatics/tech/ui/back.png");

        itemsForm.show(player).then((response) => {
            if (
                response.canceled ||
                response.selection === Object.keys(MC.itemsData).length
            ) {
                this.showMainMenu(player); // Adjust this function to go back to your main menu
            } else {
                const selectedItemName =
                    Object.keys(MC.itemsData)[response.selection];
                this.showItemSpecificPage(player, selectedItemName);
            }
        });
    }

    static showItemSpecificPage(player, selectedItemName) {
        const item = MC.itemsData[selectedItemName] || {
            description: "Details not available.",
            howToGet: "How to obtain this machine is not provided.",
            image: "textures/levelatics/tech/ui/default.png",
        };

        const itemsForm = new ActionFormData()
            .title(`§l${selectedItemName}`)
            .body(
                `§6Description:§r\n${item.description}\n\n§6How to Get:§r\n${item.howToGet}`,
            )
            .button("Go Back", item.image);

        itemsForm.show(player).then((response) => {
            if (!response.canceled) {
                this.showItemsPage(player); // Go back to the machines page
            }
        });
    }
}

export default TechGuide;
